﻿namespace DualMeetManager.Presentation
{
    partial class FieldEventEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboSchool16 = new System.Windows.Forms.ComboBox();
            this.txtPerf16 = new System.Windows.Forms.TextBox();
            this.txtName16 = new System.Windows.Forms.TextBox();
            this.lblPlace16 = new System.Windows.Forms.Label();
            this.cboSchool15 = new System.Windows.Forms.ComboBox();
            this.txtPerf15 = new System.Windows.Forms.TextBox();
            this.txtName15 = new System.Windows.Forms.TextBox();
            this.lblPlace15 = new System.Windows.Forms.Label();
            this.cboSchool14 = new System.Windows.Forms.ComboBox();
            this.txtPerf14 = new System.Windows.Forms.TextBox();
            this.txtName14 = new System.Windows.Forms.TextBox();
            this.lblPlace14 = new System.Windows.Forms.Label();
            this.cboSchool23 = new System.Windows.Forms.ComboBox();
            this.txtPerf23 = new System.Windows.Forms.TextBox();
            this.txtName23 = new System.Windows.Forms.TextBox();
            this.lblPlace23 = new System.Windows.Forms.Label();
            this.cboSchool22 = new System.Windows.Forms.ComboBox();
            this.txtPerf22 = new System.Windows.Forms.TextBox();
            this.txtName22 = new System.Windows.Forms.TextBox();
            this.lblPlace22 = new System.Windows.Forms.Label();
            this.cboSchool21 = new System.Windows.Forms.ComboBox();
            this.txtPerf21 = new System.Windows.Forms.TextBox();
            this.cboSchool13 = new System.Windows.Forms.ComboBox();
            this.txtName21 = new System.Windows.Forms.TextBox();
            this.lblPlace21 = new System.Windows.Forms.Label();
            this.cboSchool20 = new System.Windows.Forms.ComboBox();
            this.txtPerf20 = new System.Windows.Forms.TextBox();
            this.txtName20 = new System.Windows.Forms.TextBox();
            this.lblPlace20 = new System.Windows.Forms.Label();
            this.cboSchool19 = new System.Windows.Forms.ComboBox();
            this.txtPerf19 = new System.Windows.Forms.TextBox();
            this.txtName19 = new System.Windows.Forms.TextBox();
            this.cboSchool18 = new System.Windows.Forms.ComboBox();
            this.txtPerf13 = new System.Windows.Forms.TextBox();
            this.txtName13 = new System.Windows.Forms.TextBox();
            this.lblPlace13 = new System.Windows.Forms.Label();
            this.cboSchool12 = new System.Windows.Forms.ComboBox();
            this.txtPerf12 = new System.Windows.Forms.TextBox();
            this.txtName12 = new System.Windows.Forms.TextBox();
            this.lblPlace12 = new System.Windows.Forms.Label();
            this.cboSchool11 = new System.Windows.Forms.ComboBox();
            this.txtPerf11 = new System.Windows.Forms.TextBox();
            this.txtName11 = new System.Windows.Forms.TextBox();
            this.lblPlace11 = new System.Windows.Forms.Label();
            this.cboSchool10 = new System.Windows.Forms.ComboBox();
            this.txtPerf10 = new System.Windows.Forms.TextBox();
            this.txtName10 = new System.Windows.Forms.TextBox();
            this.txtPerf26 = new System.Windows.Forms.TextBox();
            this.lblPlace26 = new System.Windows.Forms.Label();
            this.cboSchool25 = new System.Windows.Forms.ComboBox();
            this.txtPerf25 = new System.Windows.Forms.TextBox();
            this.txtName25 = new System.Windows.Forms.TextBox();
            this.lblPlace25 = new System.Windows.Forms.Label();
            this.cboSchool24 = new System.Windows.Forms.ComboBox();
            this.txtPerf24 = new System.Windows.Forms.TextBox();
            this.txtName24 = new System.Windows.Forms.TextBox();
            this.lblPlace24 = new System.Windows.Forms.Label();
            this.lblPlace19 = new System.Windows.Forms.Label();
            this.lblPlace10 = new System.Windows.Forms.Label();
            this.cboSchool9 = new System.Windows.Forms.ComboBox();
            this.txtPerf9 = new System.Windows.Forms.TextBox();
            this.txtName9 = new System.Windows.Forms.TextBox();
            this.lblPlace9 = new System.Windows.Forms.Label();
            this.cboSchool8 = new System.Windows.Forms.ComboBox();
            this.txtPerf8 = new System.Windows.Forms.TextBox();
            this.txtName8 = new System.Windows.Forms.TextBox();
            this.lblPlace8 = new System.Windows.Forms.Label();
            this.cboSchool7 = new System.Windows.Forms.ComboBox();
            this.txtPerf7 = new System.Windows.Forms.TextBox();
            this.txtName7 = new System.Windows.Forms.TextBox();
            this.lblPlace7 = new System.Windows.Forms.Label();
            this.cboSchool6 = new System.Windows.Forms.ComboBox();
            this.txtPerf6 = new System.Windows.Forms.TextBox();
            this.txtName6 = new System.Windows.Forms.TextBox();
            this.txtName26 = new System.Windows.Forms.TextBox();
            this.txtPerf18 = new System.Windows.Forms.TextBox();
            this.txtName18 = new System.Windows.Forms.TextBox();
            this.lblPlace18 = new System.Windows.Forms.Label();
            this.cboSchool17 = new System.Windows.Forms.ComboBox();
            this.txtPerf17 = new System.Windows.Forms.TextBox();
            this.txtName17 = new System.Windows.Forms.TextBox();
            this.lblPlace17 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.lblPlace6 = new System.Windows.Forms.Label();
            this.cboSchool5 = new System.Windows.Forms.ComboBox();
            this.txtPerf5 = new System.Windows.Forms.TextBox();
            this.txtName5 = new System.Windows.Forms.TextBox();
            this.lblPlace5 = new System.Windows.Forms.Label();
            this.cboSchool4 = new System.Windows.Forms.ComboBox();
            this.txtPerf4 = new System.Windows.Forms.TextBox();
            this.txtName4 = new System.Windows.Forms.TextBox();
            this.lblPlace4 = new System.Windows.Forms.Label();
            this.cboSchool3 = new System.Windows.Forms.ComboBox();
            this.txtPerf3 = new System.Windows.Forms.TextBox();
            this.txtName3 = new System.Windows.Forms.TextBox();
            this.lblPlace3 = new System.Windows.Forms.Label();
            this.cboSchool2 = new System.Windows.Forms.ComboBox();
            this.txtPerf2 = new System.Windows.Forms.TextBox();
            this.txtName2 = new System.Windows.Forms.TextBox();
            this.lblPlace2 = new System.Windows.Forms.Label();
            this.cboSchool1 = new System.Windows.Forms.ComboBox();
            this.txtPerf1 = new System.Windows.Forms.TextBox();
            this.txtName1 = new System.Windows.Forms.TextBox();
            this.lblPlace1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPerf32 = new System.Windows.Forms.TextBox();
            this.grpHeats2 = new System.Windows.Forms.GroupBox();
            this.cboSchool32 = new System.Windows.Forms.ComboBox();
            this.txtName32 = new System.Windows.Forms.TextBox();
            this.lblPlace32 = new System.Windows.Forms.Label();
            this.cboSchool31 = new System.Windows.Forms.ComboBox();
            this.txtPerf31 = new System.Windows.Forms.TextBox();
            this.txtName31 = new System.Windows.Forms.TextBox();
            this.lblPlace31 = new System.Windows.Forms.Label();
            this.cboSchool30 = new System.Windows.Forms.ComboBox();
            this.txtPerf30 = new System.Windows.Forms.TextBox();
            this.txtName30 = new System.Windows.Forms.TextBox();
            this.lblPlace30 = new System.Windows.Forms.Label();
            this.cboSchool29 = new System.Windows.Forms.ComboBox();
            this.txtPerf29 = new System.Windows.Forms.TextBox();
            this.txtName29 = new System.Windows.Forms.TextBox();
            this.lblPlace29 = new System.Windows.Forms.Label();
            this.cboSchool28 = new System.Windows.Forms.ComboBox();
            this.txtPerf28 = new System.Windows.Forms.TextBox();
            this.txtName28 = new System.Windows.Forms.TextBox();
            this.lblPlace28 = new System.Windows.Forms.Label();
            this.cboSchool27 = new System.Windows.Forms.ComboBox();
            this.txtPerf27 = new System.Windows.Forms.TextBox();
            this.txtName27 = new System.Windows.Forms.TextBox();
            this.lblPlace27 = new System.Windows.Forms.Label();
            this.cboSchool26 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.cmdEnterData = new System.Windows.Forms.Button();
            this.cmdNext = new System.Windows.Forms.Button();
            this.cmdPrevious = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpHeats1 = new System.Windows.Forms.GroupBox();
            this.mnuClearThis = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClear = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrintout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.grpHeats2.SuspendLayout();
            this.grpHeats1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboSchool16
            // 
            this.cboSchool16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool16.FormattingEnabled = true;
            this.cboSchool16.Location = new System.Drawing.Point(241, 431);
            this.cboSchool16.Name = "cboSchool16";
            this.cboSchool16.Size = new System.Drawing.Size(95, 21);
            this.cboSchool16.TabIndex = 67;
            // 
            // txtPerf16
            // 
            this.txtPerf16.Location = new System.Drawing.Point(346, 431);
            this.txtPerf16.Name = "txtPerf16";
            this.txtPerf16.Size = new System.Drawing.Size(100, 20);
            this.txtPerf16.TabIndex = 66;
            // 
            // txtName16
            // 
            this.txtName16.Location = new System.Drawing.Point(57, 431);
            this.txtName16.Name = "txtName16";
            this.txtName16.Size = new System.Drawing.Size(168, 20);
            this.txtName16.TabIndex = 65;
            // 
            // lblPlace16
            // 
            this.lblPlace16.AutoSize = true;
            this.lblPlace16.Location = new System.Drawing.Point(17, 431);
            this.lblPlace16.Name = "lblPlace16";
            this.lblPlace16.Size = new System.Drawing.Size(19, 13);
            this.lblPlace16.TabIndex = 64;
            this.lblPlace16.Text = "16";
            // 
            // cboSchool15
            // 
            this.cboSchool15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool15.FormattingEnabled = true;
            this.cboSchool15.Location = new System.Drawing.Point(241, 405);
            this.cboSchool15.Name = "cboSchool15";
            this.cboSchool15.Size = new System.Drawing.Size(95, 21);
            this.cboSchool15.TabIndex = 63;
            // 
            // txtPerf15
            // 
            this.txtPerf15.Location = new System.Drawing.Point(346, 405);
            this.txtPerf15.Name = "txtPerf15";
            this.txtPerf15.Size = new System.Drawing.Size(100, 20);
            this.txtPerf15.TabIndex = 62;
            // 
            // txtName15
            // 
            this.txtName15.Location = new System.Drawing.Point(57, 405);
            this.txtName15.Name = "txtName15";
            this.txtName15.Size = new System.Drawing.Size(168, 20);
            this.txtName15.TabIndex = 61;
            // 
            // lblPlace15
            // 
            this.lblPlace15.AutoSize = true;
            this.lblPlace15.Location = new System.Drawing.Point(17, 405);
            this.lblPlace15.Name = "lblPlace15";
            this.lblPlace15.Size = new System.Drawing.Size(19, 13);
            this.lblPlace15.TabIndex = 60;
            this.lblPlace15.Text = "15";
            // 
            // cboSchool14
            // 
            this.cboSchool14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool14.FormattingEnabled = true;
            this.cboSchool14.Location = new System.Drawing.Point(241, 379);
            this.cboSchool14.Name = "cboSchool14";
            this.cboSchool14.Size = new System.Drawing.Size(95, 21);
            this.cboSchool14.TabIndex = 59;
            // 
            // txtPerf14
            // 
            this.txtPerf14.Location = new System.Drawing.Point(346, 379);
            this.txtPerf14.Name = "txtPerf14";
            this.txtPerf14.Size = new System.Drawing.Size(100, 20);
            this.txtPerf14.TabIndex = 58;
            // 
            // txtName14
            // 
            this.txtName14.Location = new System.Drawing.Point(57, 379);
            this.txtName14.Name = "txtName14";
            this.txtName14.Size = new System.Drawing.Size(168, 20);
            this.txtName14.TabIndex = 57;
            // 
            // lblPlace14
            // 
            this.lblPlace14.AutoSize = true;
            this.lblPlace14.Location = new System.Drawing.Point(17, 379);
            this.lblPlace14.Name = "lblPlace14";
            this.lblPlace14.Size = new System.Drawing.Size(19, 13);
            this.lblPlace14.TabIndex = 56;
            this.lblPlace14.Text = "14";
            // 
            // cboSchool23
            // 
            this.cboSchool23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool23.FormattingEnabled = true;
            this.cboSchool23.Location = new System.Drawing.Point(241, 197);
            this.cboSchool23.Name = "cboSchool23";
            this.cboSchool23.Size = new System.Drawing.Size(95, 21);
            this.cboSchool23.TabIndex = 31;
            // 
            // txtPerf23
            // 
            this.txtPerf23.Location = new System.Drawing.Point(346, 197);
            this.txtPerf23.Name = "txtPerf23";
            this.txtPerf23.Size = new System.Drawing.Size(100, 20);
            this.txtPerf23.TabIndex = 30;
            // 
            // txtName23
            // 
            this.txtName23.Location = new System.Drawing.Point(57, 197);
            this.txtName23.Name = "txtName23";
            this.txtName23.Size = new System.Drawing.Size(168, 20);
            this.txtName23.TabIndex = 29;
            // 
            // lblPlace23
            // 
            this.lblPlace23.AutoSize = true;
            this.lblPlace23.Location = new System.Drawing.Point(17, 197);
            this.lblPlace23.Name = "lblPlace23";
            this.lblPlace23.Size = new System.Drawing.Size(19, 13);
            this.lblPlace23.TabIndex = 28;
            this.lblPlace23.Text = "23";
            // 
            // cboSchool22
            // 
            this.cboSchool22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool22.FormattingEnabled = true;
            this.cboSchool22.Location = new System.Drawing.Point(241, 171);
            this.cboSchool22.Name = "cboSchool22";
            this.cboSchool22.Size = new System.Drawing.Size(95, 21);
            this.cboSchool22.TabIndex = 27;
            // 
            // txtPerf22
            // 
            this.txtPerf22.Location = new System.Drawing.Point(346, 171);
            this.txtPerf22.Name = "txtPerf22";
            this.txtPerf22.Size = new System.Drawing.Size(100, 20);
            this.txtPerf22.TabIndex = 26;
            // 
            // txtName22
            // 
            this.txtName22.Location = new System.Drawing.Point(57, 171);
            this.txtName22.Name = "txtName22";
            this.txtName22.Size = new System.Drawing.Size(168, 20);
            this.txtName22.TabIndex = 25;
            // 
            // lblPlace22
            // 
            this.lblPlace22.AutoSize = true;
            this.lblPlace22.Location = new System.Drawing.Point(17, 171);
            this.lblPlace22.Name = "lblPlace22";
            this.lblPlace22.Size = new System.Drawing.Size(19, 13);
            this.lblPlace22.TabIndex = 24;
            this.lblPlace22.Text = "22";
            // 
            // cboSchool21
            // 
            this.cboSchool21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool21.FormattingEnabled = true;
            this.cboSchool21.Location = new System.Drawing.Point(241, 145);
            this.cboSchool21.Name = "cboSchool21";
            this.cboSchool21.Size = new System.Drawing.Size(95, 21);
            this.cboSchool21.TabIndex = 23;
            // 
            // txtPerf21
            // 
            this.txtPerf21.Location = new System.Drawing.Point(346, 145);
            this.txtPerf21.Name = "txtPerf21";
            this.txtPerf21.Size = new System.Drawing.Size(100, 20);
            this.txtPerf21.TabIndex = 22;
            // 
            // cboSchool13
            // 
            this.cboSchool13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool13.FormattingEnabled = true;
            this.cboSchool13.Location = new System.Drawing.Point(241, 353);
            this.cboSchool13.Name = "cboSchool13";
            this.cboSchool13.Size = new System.Drawing.Size(95, 21);
            this.cboSchool13.TabIndex = 55;
            // 
            // txtName21
            // 
            this.txtName21.Location = new System.Drawing.Point(57, 145);
            this.txtName21.Name = "txtName21";
            this.txtName21.Size = new System.Drawing.Size(168, 20);
            this.txtName21.TabIndex = 21;
            // 
            // lblPlace21
            // 
            this.lblPlace21.AutoSize = true;
            this.lblPlace21.Location = new System.Drawing.Point(17, 145);
            this.lblPlace21.Name = "lblPlace21";
            this.lblPlace21.Size = new System.Drawing.Size(19, 13);
            this.lblPlace21.TabIndex = 20;
            this.lblPlace21.Text = "21";
            // 
            // cboSchool20
            // 
            this.cboSchool20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool20.FormattingEnabled = true;
            this.cboSchool20.Location = new System.Drawing.Point(241, 119);
            this.cboSchool20.Name = "cboSchool20";
            this.cboSchool20.Size = new System.Drawing.Size(95, 21);
            this.cboSchool20.TabIndex = 19;
            // 
            // txtPerf20
            // 
            this.txtPerf20.Location = new System.Drawing.Point(346, 119);
            this.txtPerf20.Name = "txtPerf20";
            this.txtPerf20.Size = new System.Drawing.Size(100, 20);
            this.txtPerf20.TabIndex = 18;
            // 
            // txtName20
            // 
            this.txtName20.Location = new System.Drawing.Point(57, 119);
            this.txtName20.Name = "txtName20";
            this.txtName20.Size = new System.Drawing.Size(168, 20);
            this.txtName20.TabIndex = 17;
            // 
            // lblPlace20
            // 
            this.lblPlace20.AutoSize = true;
            this.lblPlace20.Location = new System.Drawing.Point(17, 119);
            this.lblPlace20.Name = "lblPlace20";
            this.lblPlace20.Size = new System.Drawing.Size(19, 13);
            this.lblPlace20.TabIndex = 16;
            this.lblPlace20.Text = "20";
            // 
            // cboSchool19
            // 
            this.cboSchool19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool19.FormattingEnabled = true;
            this.cboSchool19.Location = new System.Drawing.Point(241, 93);
            this.cboSchool19.Name = "cboSchool19";
            this.cboSchool19.Size = new System.Drawing.Size(95, 21);
            this.cboSchool19.TabIndex = 15;
            // 
            // txtPerf19
            // 
            this.txtPerf19.Location = new System.Drawing.Point(346, 93);
            this.txtPerf19.Name = "txtPerf19";
            this.txtPerf19.Size = new System.Drawing.Size(100, 20);
            this.txtPerf19.TabIndex = 14;
            // 
            // txtName19
            // 
            this.txtName19.Location = new System.Drawing.Point(57, 93);
            this.txtName19.Name = "txtName19";
            this.txtName19.Size = new System.Drawing.Size(168, 20);
            this.txtName19.TabIndex = 13;
            // 
            // cboSchool18
            // 
            this.cboSchool18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool18.FormattingEnabled = true;
            this.cboSchool18.Location = new System.Drawing.Point(241, 67);
            this.cboSchool18.Name = "cboSchool18";
            this.cboSchool18.Size = new System.Drawing.Size(95, 21);
            this.cboSchool18.TabIndex = 11;
            // 
            // txtPerf13
            // 
            this.txtPerf13.Location = new System.Drawing.Point(346, 353);
            this.txtPerf13.Name = "txtPerf13";
            this.txtPerf13.Size = new System.Drawing.Size(100, 20);
            this.txtPerf13.TabIndex = 54;
            // 
            // txtName13
            // 
            this.txtName13.Location = new System.Drawing.Point(57, 353);
            this.txtName13.Name = "txtName13";
            this.txtName13.Size = new System.Drawing.Size(168, 20);
            this.txtName13.TabIndex = 53;
            // 
            // lblPlace13
            // 
            this.lblPlace13.AutoSize = true;
            this.lblPlace13.Location = new System.Drawing.Point(17, 353);
            this.lblPlace13.Name = "lblPlace13";
            this.lblPlace13.Size = new System.Drawing.Size(19, 13);
            this.lblPlace13.TabIndex = 52;
            this.lblPlace13.Text = "13";
            // 
            // cboSchool12
            // 
            this.cboSchool12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool12.FormattingEnabled = true;
            this.cboSchool12.Location = new System.Drawing.Point(241, 327);
            this.cboSchool12.Name = "cboSchool12";
            this.cboSchool12.Size = new System.Drawing.Size(95, 21);
            this.cboSchool12.TabIndex = 51;
            // 
            // txtPerf12
            // 
            this.txtPerf12.Location = new System.Drawing.Point(346, 327);
            this.txtPerf12.Name = "txtPerf12";
            this.txtPerf12.Size = new System.Drawing.Size(100, 20);
            this.txtPerf12.TabIndex = 50;
            // 
            // txtName12
            // 
            this.txtName12.Location = new System.Drawing.Point(57, 327);
            this.txtName12.Name = "txtName12";
            this.txtName12.Size = new System.Drawing.Size(168, 20);
            this.txtName12.TabIndex = 49;
            // 
            // lblPlace12
            // 
            this.lblPlace12.AutoSize = true;
            this.lblPlace12.Location = new System.Drawing.Point(17, 327);
            this.lblPlace12.Name = "lblPlace12";
            this.lblPlace12.Size = new System.Drawing.Size(19, 13);
            this.lblPlace12.TabIndex = 48;
            this.lblPlace12.Text = "12";
            // 
            // cboSchool11
            // 
            this.cboSchool11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool11.FormattingEnabled = true;
            this.cboSchool11.Location = new System.Drawing.Point(241, 301);
            this.cboSchool11.Name = "cboSchool11";
            this.cboSchool11.Size = new System.Drawing.Size(95, 21);
            this.cboSchool11.TabIndex = 47;
            // 
            // txtPerf11
            // 
            this.txtPerf11.Location = new System.Drawing.Point(346, 301);
            this.txtPerf11.Name = "txtPerf11";
            this.txtPerf11.Size = new System.Drawing.Size(100, 20);
            this.txtPerf11.TabIndex = 46;
            // 
            // txtName11
            // 
            this.txtName11.Location = new System.Drawing.Point(57, 301);
            this.txtName11.Name = "txtName11";
            this.txtName11.Size = new System.Drawing.Size(168, 20);
            this.txtName11.TabIndex = 45;
            // 
            // lblPlace11
            // 
            this.lblPlace11.AutoSize = true;
            this.lblPlace11.Location = new System.Drawing.Point(17, 301);
            this.lblPlace11.Name = "lblPlace11";
            this.lblPlace11.Size = new System.Drawing.Size(19, 13);
            this.lblPlace11.TabIndex = 44;
            this.lblPlace11.Text = "11";
            // 
            // cboSchool10
            // 
            this.cboSchool10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool10.FormattingEnabled = true;
            this.cboSchool10.Location = new System.Drawing.Point(241, 275);
            this.cboSchool10.Name = "cboSchool10";
            this.cboSchool10.Size = new System.Drawing.Size(95, 21);
            this.cboSchool10.TabIndex = 43;
            // 
            // txtPerf10
            // 
            this.txtPerf10.Location = new System.Drawing.Point(346, 275);
            this.txtPerf10.Name = "txtPerf10";
            this.txtPerf10.Size = new System.Drawing.Size(100, 20);
            this.txtPerf10.TabIndex = 42;
            // 
            // txtName10
            // 
            this.txtName10.Location = new System.Drawing.Point(57, 275);
            this.txtName10.Name = "txtName10";
            this.txtName10.Size = new System.Drawing.Size(168, 20);
            this.txtName10.TabIndex = 41;
            // 
            // txtPerf26
            // 
            this.txtPerf26.Location = new System.Drawing.Point(346, 275);
            this.txtPerf26.Name = "txtPerf26";
            this.txtPerf26.Size = new System.Drawing.Size(100, 20);
            this.txtPerf26.TabIndex = 42;
            // 
            // lblPlace26
            // 
            this.lblPlace26.AutoSize = true;
            this.lblPlace26.Location = new System.Drawing.Point(17, 275);
            this.lblPlace26.Name = "lblPlace26";
            this.lblPlace26.Size = new System.Drawing.Size(19, 13);
            this.lblPlace26.TabIndex = 40;
            this.lblPlace26.Text = "26";
            // 
            // cboSchool25
            // 
            this.cboSchool25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool25.FormattingEnabled = true;
            this.cboSchool25.Location = new System.Drawing.Point(241, 249);
            this.cboSchool25.Name = "cboSchool25";
            this.cboSchool25.Size = new System.Drawing.Size(95, 21);
            this.cboSchool25.TabIndex = 39;
            // 
            // txtPerf25
            // 
            this.txtPerf25.Location = new System.Drawing.Point(346, 249);
            this.txtPerf25.Name = "txtPerf25";
            this.txtPerf25.Size = new System.Drawing.Size(100, 20);
            this.txtPerf25.TabIndex = 38;
            // 
            // txtName25
            // 
            this.txtName25.Location = new System.Drawing.Point(57, 249);
            this.txtName25.Name = "txtName25";
            this.txtName25.Size = new System.Drawing.Size(168, 20);
            this.txtName25.TabIndex = 37;
            // 
            // lblPlace25
            // 
            this.lblPlace25.AutoSize = true;
            this.lblPlace25.Location = new System.Drawing.Point(17, 249);
            this.lblPlace25.Name = "lblPlace25";
            this.lblPlace25.Size = new System.Drawing.Size(19, 13);
            this.lblPlace25.TabIndex = 36;
            this.lblPlace25.Text = "25";
            // 
            // cboSchool24
            // 
            this.cboSchool24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool24.FormattingEnabled = true;
            this.cboSchool24.Location = new System.Drawing.Point(241, 223);
            this.cboSchool24.Name = "cboSchool24";
            this.cboSchool24.Size = new System.Drawing.Size(95, 21);
            this.cboSchool24.TabIndex = 35;
            // 
            // txtPerf24
            // 
            this.txtPerf24.Location = new System.Drawing.Point(346, 223);
            this.txtPerf24.Name = "txtPerf24";
            this.txtPerf24.Size = new System.Drawing.Size(100, 20);
            this.txtPerf24.TabIndex = 34;
            // 
            // txtName24
            // 
            this.txtName24.Location = new System.Drawing.Point(57, 223);
            this.txtName24.Name = "txtName24";
            this.txtName24.Size = new System.Drawing.Size(168, 20);
            this.txtName24.TabIndex = 33;
            // 
            // lblPlace24
            // 
            this.lblPlace24.AutoSize = true;
            this.lblPlace24.Location = new System.Drawing.Point(17, 223);
            this.lblPlace24.Name = "lblPlace24";
            this.lblPlace24.Size = new System.Drawing.Size(19, 13);
            this.lblPlace24.TabIndex = 32;
            this.lblPlace24.Text = "24";
            // 
            // lblPlace19
            // 
            this.lblPlace19.AutoSize = true;
            this.lblPlace19.Location = new System.Drawing.Point(17, 93);
            this.lblPlace19.Name = "lblPlace19";
            this.lblPlace19.Size = new System.Drawing.Size(19, 13);
            this.lblPlace19.TabIndex = 12;
            this.lblPlace19.Text = "19";
            // 
            // lblPlace10
            // 
            this.lblPlace10.AutoSize = true;
            this.lblPlace10.Location = new System.Drawing.Point(17, 275);
            this.lblPlace10.Name = "lblPlace10";
            this.lblPlace10.Size = new System.Drawing.Size(19, 13);
            this.lblPlace10.TabIndex = 40;
            this.lblPlace10.Text = "10";
            // 
            // cboSchool9
            // 
            this.cboSchool9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool9.FormattingEnabled = true;
            this.cboSchool9.Location = new System.Drawing.Point(241, 249);
            this.cboSchool9.Name = "cboSchool9";
            this.cboSchool9.Size = new System.Drawing.Size(95, 21);
            this.cboSchool9.TabIndex = 39;
            // 
            // txtPerf9
            // 
            this.txtPerf9.Location = new System.Drawing.Point(346, 249);
            this.txtPerf9.Name = "txtPerf9";
            this.txtPerf9.Size = new System.Drawing.Size(100, 20);
            this.txtPerf9.TabIndex = 38;
            // 
            // txtName9
            // 
            this.txtName9.Location = new System.Drawing.Point(57, 249);
            this.txtName9.Name = "txtName9";
            this.txtName9.Size = new System.Drawing.Size(168, 20);
            this.txtName9.TabIndex = 37;
            // 
            // lblPlace9
            // 
            this.lblPlace9.AutoSize = true;
            this.lblPlace9.Location = new System.Drawing.Point(17, 249);
            this.lblPlace9.Name = "lblPlace9";
            this.lblPlace9.Size = new System.Drawing.Size(13, 13);
            this.lblPlace9.TabIndex = 36;
            this.lblPlace9.Text = "9";
            // 
            // cboSchool8
            // 
            this.cboSchool8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool8.FormattingEnabled = true;
            this.cboSchool8.Location = new System.Drawing.Point(241, 223);
            this.cboSchool8.Name = "cboSchool8";
            this.cboSchool8.Size = new System.Drawing.Size(95, 21);
            this.cboSchool8.TabIndex = 35;
            // 
            // txtPerf8
            // 
            this.txtPerf8.Location = new System.Drawing.Point(346, 223);
            this.txtPerf8.Name = "txtPerf8";
            this.txtPerf8.Size = new System.Drawing.Size(100, 20);
            this.txtPerf8.TabIndex = 34;
            // 
            // txtName8
            // 
            this.txtName8.Location = new System.Drawing.Point(57, 223);
            this.txtName8.Name = "txtName8";
            this.txtName8.Size = new System.Drawing.Size(168, 20);
            this.txtName8.TabIndex = 33;
            // 
            // lblPlace8
            // 
            this.lblPlace8.AutoSize = true;
            this.lblPlace8.Location = new System.Drawing.Point(17, 223);
            this.lblPlace8.Name = "lblPlace8";
            this.lblPlace8.Size = new System.Drawing.Size(13, 13);
            this.lblPlace8.TabIndex = 32;
            this.lblPlace8.Text = "8";
            // 
            // cboSchool7
            // 
            this.cboSchool7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool7.FormattingEnabled = true;
            this.cboSchool7.Location = new System.Drawing.Point(241, 197);
            this.cboSchool7.Name = "cboSchool7";
            this.cboSchool7.Size = new System.Drawing.Size(95, 21);
            this.cboSchool7.TabIndex = 31;
            // 
            // txtPerf7
            // 
            this.txtPerf7.Location = new System.Drawing.Point(346, 197);
            this.txtPerf7.Name = "txtPerf7";
            this.txtPerf7.Size = new System.Drawing.Size(100, 20);
            this.txtPerf7.TabIndex = 30;
            // 
            // txtName7
            // 
            this.txtName7.Location = new System.Drawing.Point(57, 197);
            this.txtName7.Name = "txtName7";
            this.txtName7.Size = new System.Drawing.Size(168, 20);
            this.txtName7.TabIndex = 29;
            // 
            // lblPlace7
            // 
            this.lblPlace7.AutoSize = true;
            this.lblPlace7.Location = new System.Drawing.Point(17, 197);
            this.lblPlace7.Name = "lblPlace7";
            this.lblPlace7.Size = new System.Drawing.Size(13, 13);
            this.lblPlace7.TabIndex = 28;
            this.lblPlace7.Text = "7";
            // 
            // cboSchool6
            // 
            this.cboSchool6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool6.FormattingEnabled = true;
            this.cboSchool6.Location = new System.Drawing.Point(241, 171);
            this.cboSchool6.Name = "cboSchool6";
            this.cboSchool6.Size = new System.Drawing.Size(95, 21);
            this.cboSchool6.TabIndex = 27;
            // 
            // txtPerf6
            // 
            this.txtPerf6.Location = new System.Drawing.Point(346, 171);
            this.txtPerf6.Name = "txtPerf6";
            this.txtPerf6.Size = new System.Drawing.Size(100, 20);
            this.txtPerf6.TabIndex = 26;
            // 
            // txtName6
            // 
            this.txtName6.Location = new System.Drawing.Point(57, 171);
            this.txtName6.Name = "txtName6";
            this.txtName6.Size = new System.Drawing.Size(168, 20);
            this.txtName6.TabIndex = 25;
            // 
            // txtName26
            // 
            this.txtName26.Location = new System.Drawing.Point(57, 275);
            this.txtName26.Name = "txtName26";
            this.txtName26.Size = new System.Drawing.Size(168, 20);
            this.txtName26.TabIndex = 41;
            // 
            // txtPerf18
            // 
            this.txtPerf18.Location = new System.Drawing.Point(346, 67);
            this.txtPerf18.Name = "txtPerf18";
            this.txtPerf18.Size = new System.Drawing.Size(100, 20);
            this.txtPerf18.TabIndex = 10;
            // 
            // txtName18
            // 
            this.txtName18.Location = new System.Drawing.Point(57, 67);
            this.txtName18.Name = "txtName18";
            this.txtName18.Size = new System.Drawing.Size(168, 20);
            this.txtName18.TabIndex = 9;
            // 
            // lblPlace18
            // 
            this.lblPlace18.AutoSize = true;
            this.lblPlace18.Location = new System.Drawing.Point(17, 67);
            this.lblPlace18.Name = "lblPlace18";
            this.lblPlace18.Size = new System.Drawing.Size(19, 13);
            this.lblPlace18.TabIndex = 8;
            this.lblPlace18.Text = "18";
            // 
            // cboSchool17
            // 
            this.cboSchool17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool17.FormattingEnabled = true;
            this.cboSchool17.Location = new System.Drawing.Point(241, 41);
            this.cboSchool17.Name = "cboSchool17";
            this.cboSchool17.Size = new System.Drawing.Size(95, 21);
            this.cboSchool17.TabIndex = 7;
            // 
            // txtPerf17
            // 
            this.txtPerf17.Location = new System.Drawing.Point(346, 41);
            this.txtPerf17.Name = "txtPerf17";
            this.txtPerf17.Size = new System.Drawing.Size(100, 20);
            this.txtPerf17.TabIndex = 6;
            // 
            // txtName17
            // 
            this.txtName17.Location = new System.Drawing.Point(57, 41);
            this.txtName17.Name = "txtName17";
            this.txtName17.Size = new System.Drawing.Size(168, 20);
            this.txtName17.TabIndex = 5;
            // 
            // lblPlace17
            // 
            this.lblPlace17.AutoSize = true;
            this.lblPlace17.Location = new System.Drawing.Point(17, 41);
            this.lblPlace17.Name = "lblPlace17";
            this.lblPlace17.Size = new System.Drawing.Size(19, 13);
            this.lblPlace17.TabIndex = 4;
            this.lblPlace17.Text = "17";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(359, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(67, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Performance";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(254, 20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "School";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(7, 20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(34, 13);
            this.label40.TabIndex = 0;
            this.label40.Text = "Place";
            // 
            // lblPlace6
            // 
            this.lblPlace6.AutoSize = true;
            this.lblPlace6.Location = new System.Drawing.Point(17, 171);
            this.lblPlace6.Name = "lblPlace6";
            this.lblPlace6.Size = new System.Drawing.Size(13, 13);
            this.lblPlace6.TabIndex = 24;
            this.lblPlace6.Text = "6";
            // 
            // cboSchool5
            // 
            this.cboSchool5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool5.FormattingEnabled = true;
            this.cboSchool5.Location = new System.Drawing.Point(241, 145);
            this.cboSchool5.Name = "cboSchool5";
            this.cboSchool5.Size = new System.Drawing.Size(95, 21);
            this.cboSchool5.TabIndex = 23;
            // 
            // txtPerf5
            // 
            this.txtPerf5.Location = new System.Drawing.Point(346, 145);
            this.txtPerf5.Name = "txtPerf5";
            this.txtPerf5.Size = new System.Drawing.Size(100, 20);
            this.txtPerf5.TabIndex = 22;
            // 
            // txtName5
            // 
            this.txtName5.Location = new System.Drawing.Point(57, 145);
            this.txtName5.Name = "txtName5";
            this.txtName5.Size = new System.Drawing.Size(168, 20);
            this.txtName5.TabIndex = 21;
            // 
            // lblPlace5
            // 
            this.lblPlace5.AutoSize = true;
            this.lblPlace5.Location = new System.Drawing.Point(17, 145);
            this.lblPlace5.Name = "lblPlace5";
            this.lblPlace5.Size = new System.Drawing.Size(13, 13);
            this.lblPlace5.TabIndex = 20;
            this.lblPlace5.Text = "5";
            // 
            // cboSchool4
            // 
            this.cboSchool4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool4.FormattingEnabled = true;
            this.cboSchool4.Location = new System.Drawing.Point(241, 119);
            this.cboSchool4.Name = "cboSchool4";
            this.cboSchool4.Size = new System.Drawing.Size(95, 21);
            this.cboSchool4.TabIndex = 19;
            // 
            // txtPerf4
            // 
            this.txtPerf4.Location = new System.Drawing.Point(346, 119);
            this.txtPerf4.Name = "txtPerf4";
            this.txtPerf4.Size = new System.Drawing.Size(100, 20);
            this.txtPerf4.TabIndex = 18;
            // 
            // txtName4
            // 
            this.txtName4.Location = new System.Drawing.Point(57, 119);
            this.txtName4.Name = "txtName4";
            this.txtName4.Size = new System.Drawing.Size(168, 20);
            this.txtName4.TabIndex = 17;
            // 
            // lblPlace4
            // 
            this.lblPlace4.AutoSize = true;
            this.lblPlace4.Location = new System.Drawing.Point(17, 119);
            this.lblPlace4.Name = "lblPlace4";
            this.lblPlace4.Size = new System.Drawing.Size(13, 13);
            this.lblPlace4.TabIndex = 16;
            this.lblPlace4.Text = "4";
            // 
            // cboSchool3
            // 
            this.cboSchool3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool3.FormattingEnabled = true;
            this.cboSchool3.Location = new System.Drawing.Point(241, 93);
            this.cboSchool3.Name = "cboSchool3";
            this.cboSchool3.Size = new System.Drawing.Size(95, 21);
            this.cboSchool3.TabIndex = 15;
            // 
            // txtPerf3
            // 
            this.txtPerf3.Location = new System.Drawing.Point(346, 93);
            this.txtPerf3.Name = "txtPerf3";
            this.txtPerf3.Size = new System.Drawing.Size(100, 20);
            this.txtPerf3.TabIndex = 14;
            // 
            // txtName3
            // 
            this.txtName3.Location = new System.Drawing.Point(57, 93);
            this.txtName3.Name = "txtName3";
            this.txtName3.Size = new System.Drawing.Size(168, 20);
            this.txtName3.TabIndex = 13;
            // 
            // lblPlace3
            // 
            this.lblPlace3.AutoSize = true;
            this.lblPlace3.Location = new System.Drawing.Point(17, 93);
            this.lblPlace3.Name = "lblPlace3";
            this.lblPlace3.Size = new System.Drawing.Size(13, 13);
            this.lblPlace3.TabIndex = 12;
            this.lblPlace3.Text = "3";
            // 
            // cboSchool2
            // 
            this.cboSchool2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool2.FormattingEnabled = true;
            this.cboSchool2.Location = new System.Drawing.Point(241, 67);
            this.cboSchool2.Name = "cboSchool2";
            this.cboSchool2.Size = new System.Drawing.Size(95, 21);
            this.cboSchool2.TabIndex = 11;
            // 
            // txtPerf2
            // 
            this.txtPerf2.Location = new System.Drawing.Point(346, 67);
            this.txtPerf2.Name = "txtPerf2";
            this.txtPerf2.Size = new System.Drawing.Size(100, 20);
            this.txtPerf2.TabIndex = 10;
            // 
            // txtName2
            // 
            this.txtName2.Location = new System.Drawing.Point(57, 67);
            this.txtName2.Name = "txtName2";
            this.txtName2.Size = new System.Drawing.Size(168, 20);
            this.txtName2.TabIndex = 9;
            // 
            // lblPlace2
            // 
            this.lblPlace2.AutoSize = true;
            this.lblPlace2.Location = new System.Drawing.Point(17, 67);
            this.lblPlace2.Name = "lblPlace2";
            this.lblPlace2.Size = new System.Drawing.Size(13, 13);
            this.lblPlace2.TabIndex = 8;
            this.lblPlace2.Text = "2";
            // 
            // cboSchool1
            // 
            this.cboSchool1.BackColor = System.Drawing.SystemColors.Window;
            this.cboSchool1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool1.FormattingEnabled = true;
            this.cboSchool1.Location = new System.Drawing.Point(241, 41);
            this.cboSchool1.Name = "cboSchool1";
            this.cboSchool1.Size = new System.Drawing.Size(95, 21);
            this.cboSchool1.TabIndex = 7;
            // 
            // txtPerf1
            // 
            this.txtPerf1.Location = new System.Drawing.Point(346, 41);
            this.txtPerf1.Name = "txtPerf1";
            this.txtPerf1.Size = new System.Drawing.Size(100, 20);
            this.txtPerf1.TabIndex = 6;
            // 
            // txtName1
            // 
            this.txtName1.Location = new System.Drawing.Point(57, 41);
            this.txtName1.Name = "txtName1";
            this.txtName1.Size = new System.Drawing.Size(168, 20);
            this.txtName1.TabIndex = 5;
            // 
            // lblPlace1
            // 
            this.lblPlace1.AutoSize = true;
            this.lblPlace1.Location = new System.Drawing.Point(17, 41);
            this.lblPlace1.Name = "lblPlace1";
            this.lblPlace1.Size = new System.Drawing.Size(13, 13);
            this.lblPlace1.TabIndex = 4;
            this.lblPlace1.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(359, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Performance";
            // 
            // txtPerf32
            // 
            this.txtPerf32.Location = new System.Drawing.Point(346, 431);
            this.txtPerf32.Name = "txtPerf32";
            this.txtPerf32.Size = new System.Drawing.Size(100, 20);
            this.txtPerf32.TabIndex = 66;
            // 
            // grpHeats2
            // 
            this.grpHeats2.Controls.Add(this.cboSchool32);
            this.grpHeats2.Controls.Add(this.txtPerf32);
            this.grpHeats2.Controls.Add(this.txtName32);
            this.grpHeats2.Controls.Add(this.lblPlace32);
            this.grpHeats2.Controls.Add(this.cboSchool31);
            this.grpHeats2.Controls.Add(this.txtPerf31);
            this.grpHeats2.Controls.Add(this.txtName31);
            this.grpHeats2.Controls.Add(this.lblPlace31);
            this.grpHeats2.Controls.Add(this.cboSchool30);
            this.grpHeats2.Controls.Add(this.txtPerf30);
            this.grpHeats2.Controls.Add(this.txtName30);
            this.grpHeats2.Controls.Add(this.lblPlace30);
            this.grpHeats2.Controls.Add(this.cboSchool29);
            this.grpHeats2.Controls.Add(this.txtPerf29);
            this.grpHeats2.Controls.Add(this.txtName29);
            this.grpHeats2.Controls.Add(this.lblPlace29);
            this.grpHeats2.Controls.Add(this.cboSchool28);
            this.grpHeats2.Controls.Add(this.txtPerf28);
            this.grpHeats2.Controls.Add(this.txtName28);
            this.grpHeats2.Controls.Add(this.lblPlace28);
            this.grpHeats2.Controls.Add(this.cboSchool27);
            this.grpHeats2.Controls.Add(this.txtPerf27);
            this.grpHeats2.Controls.Add(this.txtName27);
            this.grpHeats2.Controls.Add(this.lblPlace27);
            this.grpHeats2.Controls.Add(this.cboSchool26);
            this.grpHeats2.Controls.Add(this.txtPerf26);
            this.grpHeats2.Controls.Add(this.txtName26);
            this.grpHeats2.Controls.Add(this.lblPlace26);
            this.grpHeats2.Controls.Add(this.cboSchool25);
            this.grpHeats2.Controls.Add(this.txtPerf25);
            this.grpHeats2.Controls.Add(this.txtName25);
            this.grpHeats2.Controls.Add(this.lblPlace25);
            this.grpHeats2.Controls.Add(this.cboSchool24);
            this.grpHeats2.Controls.Add(this.txtPerf24);
            this.grpHeats2.Controls.Add(this.txtName24);
            this.grpHeats2.Controls.Add(this.lblPlace24);
            this.grpHeats2.Controls.Add(this.cboSchool23);
            this.grpHeats2.Controls.Add(this.txtPerf23);
            this.grpHeats2.Controls.Add(this.txtName23);
            this.grpHeats2.Controls.Add(this.lblPlace23);
            this.grpHeats2.Controls.Add(this.cboSchool22);
            this.grpHeats2.Controls.Add(this.txtPerf22);
            this.grpHeats2.Controls.Add(this.txtName22);
            this.grpHeats2.Controls.Add(this.lblPlace22);
            this.grpHeats2.Controls.Add(this.cboSchool21);
            this.grpHeats2.Controls.Add(this.txtPerf21);
            this.grpHeats2.Controls.Add(this.txtName21);
            this.grpHeats2.Controls.Add(this.lblPlace21);
            this.grpHeats2.Controls.Add(this.cboSchool20);
            this.grpHeats2.Controls.Add(this.txtPerf20);
            this.grpHeats2.Controls.Add(this.txtName20);
            this.grpHeats2.Controls.Add(this.lblPlace20);
            this.grpHeats2.Controls.Add(this.cboSchool19);
            this.grpHeats2.Controls.Add(this.txtPerf19);
            this.grpHeats2.Controls.Add(this.txtName19);
            this.grpHeats2.Controls.Add(this.lblPlace19);
            this.grpHeats2.Controls.Add(this.cboSchool18);
            this.grpHeats2.Controls.Add(this.txtPerf18);
            this.grpHeats2.Controls.Add(this.txtName18);
            this.grpHeats2.Controls.Add(this.lblPlace18);
            this.grpHeats2.Controls.Add(this.cboSchool17);
            this.grpHeats2.Controls.Add(this.txtPerf17);
            this.grpHeats2.Controls.Add(this.txtName17);
            this.grpHeats2.Controls.Add(this.lblPlace17);
            this.grpHeats2.Controls.Add(this.label37);
            this.grpHeats2.Controls.Add(this.label38);
            this.grpHeats2.Controls.Add(this.label39);
            this.grpHeats2.Controls.Add(this.label40);
            this.grpHeats2.Location = new System.Drawing.Point(519, 101);
            this.grpHeats2.Name = "grpHeats2";
            this.grpHeats2.Size = new System.Drawing.Size(460, 465);
            this.grpHeats2.TabIndex = 11;
            this.grpHeats2.TabStop = false;
            this.grpHeats2.Text = "Flight #1";
            // 
            // cboSchool32
            // 
            this.cboSchool32.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool32.FormattingEnabled = true;
            this.cboSchool32.Location = new System.Drawing.Point(241, 431);
            this.cboSchool32.Name = "cboSchool32";
            this.cboSchool32.Size = new System.Drawing.Size(95, 21);
            this.cboSchool32.TabIndex = 67;
            // 
            // txtName32
            // 
            this.txtName32.Location = new System.Drawing.Point(57, 431);
            this.txtName32.Name = "txtName32";
            this.txtName32.Size = new System.Drawing.Size(168, 20);
            this.txtName32.TabIndex = 65;
            // 
            // lblPlace32
            // 
            this.lblPlace32.AutoSize = true;
            this.lblPlace32.Location = new System.Drawing.Point(17, 431);
            this.lblPlace32.Name = "lblPlace32";
            this.lblPlace32.Size = new System.Drawing.Size(19, 13);
            this.lblPlace32.TabIndex = 64;
            this.lblPlace32.Text = "32";
            // 
            // cboSchool31
            // 
            this.cboSchool31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool31.FormattingEnabled = true;
            this.cboSchool31.Location = new System.Drawing.Point(241, 405);
            this.cboSchool31.Name = "cboSchool31";
            this.cboSchool31.Size = new System.Drawing.Size(95, 21);
            this.cboSchool31.TabIndex = 63;
            // 
            // txtPerf31
            // 
            this.txtPerf31.Location = new System.Drawing.Point(346, 405);
            this.txtPerf31.Name = "txtPerf31";
            this.txtPerf31.Size = new System.Drawing.Size(100, 20);
            this.txtPerf31.TabIndex = 62;
            // 
            // txtName31
            // 
            this.txtName31.Location = new System.Drawing.Point(57, 405);
            this.txtName31.Name = "txtName31";
            this.txtName31.Size = new System.Drawing.Size(168, 20);
            this.txtName31.TabIndex = 61;
            // 
            // lblPlace31
            // 
            this.lblPlace31.AutoSize = true;
            this.lblPlace31.Location = new System.Drawing.Point(17, 405);
            this.lblPlace31.Name = "lblPlace31";
            this.lblPlace31.Size = new System.Drawing.Size(19, 13);
            this.lblPlace31.TabIndex = 60;
            this.lblPlace31.Text = "31";
            // 
            // cboSchool30
            // 
            this.cboSchool30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool30.FormattingEnabled = true;
            this.cboSchool30.Location = new System.Drawing.Point(241, 379);
            this.cboSchool30.Name = "cboSchool30";
            this.cboSchool30.Size = new System.Drawing.Size(95, 21);
            this.cboSchool30.TabIndex = 59;
            // 
            // txtPerf30
            // 
            this.txtPerf30.Location = new System.Drawing.Point(346, 379);
            this.txtPerf30.Name = "txtPerf30";
            this.txtPerf30.Size = new System.Drawing.Size(100, 20);
            this.txtPerf30.TabIndex = 58;
            // 
            // txtName30
            // 
            this.txtName30.Location = new System.Drawing.Point(57, 379);
            this.txtName30.Name = "txtName30";
            this.txtName30.Size = new System.Drawing.Size(168, 20);
            this.txtName30.TabIndex = 57;
            // 
            // lblPlace30
            // 
            this.lblPlace30.AutoSize = true;
            this.lblPlace30.Location = new System.Drawing.Point(17, 379);
            this.lblPlace30.Name = "lblPlace30";
            this.lblPlace30.Size = new System.Drawing.Size(19, 13);
            this.lblPlace30.TabIndex = 56;
            this.lblPlace30.Text = "30";
            // 
            // cboSchool29
            // 
            this.cboSchool29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool29.FormattingEnabled = true;
            this.cboSchool29.Location = new System.Drawing.Point(241, 353);
            this.cboSchool29.Name = "cboSchool29";
            this.cboSchool29.Size = new System.Drawing.Size(95, 21);
            this.cboSchool29.TabIndex = 55;
            // 
            // txtPerf29
            // 
            this.txtPerf29.Location = new System.Drawing.Point(346, 353);
            this.txtPerf29.Name = "txtPerf29";
            this.txtPerf29.Size = new System.Drawing.Size(100, 20);
            this.txtPerf29.TabIndex = 54;
            // 
            // txtName29
            // 
            this.txtName29.Location = new System.Drawing.Point(57, 353);
            this.txtName29.Name = "txtName29";
            this.txtName29.Size = new System.Drawing.Size(168, 20);
            this.txtName29.TabIndex = 53;
            // 
            // lblPlace29
            // 
            this.lblPlace29.AutoSize = true;
            this.lblPlace29.Location = new System.Drawing.Point(17, 353);
            this.lblPlace29.Name = "lblPlace29";
            this.lblPlace29.Size = new System.Drawing.Size(19, 13);
            this.lblPlace29.TabIndex = 52;
            this.lblPlace29.Text = "29";
            // 
            // cboSchool28
            // 
            this.cboSchool28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool28.FormattingEnabled = true;
            this.cboSchool28.Location = new System.Drawing.Point(241, 327);
            this.cboSchool28.Name = "cboSchool28";
            this.cboSchool28.Size = new System.Drawing.Size(95, 21);
            this.cboSchool28.TabIndex = 51;
            // 
            // txtPerf28
            // 
            this.txtPerf28.Location = new System.Drawing.Point(346, 327);
            this.txtPerf28.Name = "txtPerf28";
            this.txtPerf28.Size = new System.Drawing.Size(100, 20);
            this.txtPerf28.TabIndex = 50;
            // 
            // txtName28
            // 
            this.txtName28.Location = new System.Drawing.Point(57, 327);
            this.txtName28.Name = "txtName28";
            this.txtName28.Size = new System.Drawing.Size(168, 20);
            this.txtName28.TabIndex = 49;
            // 
            // lblPlace28
            // 
            this.lblPlace28.AutoSize = true;
            this.lblPlace28.Location = new System.Drawing.Point(17, 327);
            this.lblPlace28.Name = "lblPlace28";
            this.lblPlace28.Size = new System.Drawing.Size(19, 13);
            this.lblPlace28.TabIndex = 48;
            this.lblPlace28.Text = "28";
            // 
            // cboSchool27
            // 
            this.cboSchool27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool27.FormattingEnabled = true;
            this.cboSchool27.Location = new System.Drawing.Point(241, 301);
            this.cboSchool27.Name = "cboSchool27";
            this.cboSchool27.Size = new System.Drawing.Size(95, 21);
            this.cboSchool27.TabIndex = 47;
            // 
            // txtPerf27
            // 
            this.txtPerf27.Location = new System.Drawing.Point(346, 301);
            this.txtPerf27.Name = "txtPerf27";
            this.txtPerf27.Size = new System.Drawing.Size(100, 20);
            this.txtPerf27.TabIndex = 46;
            // 
            // txtName27
            // 
            this.txtName27.Location = new System.Drawing.Point(57, 301);
            this.txtName27.Name = "txtName27";
            this.txtName27.Size = new System.Drawing.Size(168, 20);
            this.txtName27.TabIndex = 45;
            // 
            // lblPlace27
            // 
            this.lblPlace27.AutoSize = true;
            this.lblPlace27.Location = new System.Drawing.Point(17, 301);
            this.lblPlace27.Name = "lblPlace27";
            this.lblPlace27.Size = new System.Drawing.Size(19, 13);
            this.lblPlace27.TabIndex = 44;
            this.lblPlace27.Text = "27";
            // 
            // cboSchool26
            // 
            this.cboSchool26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool26.FormattingEnabled = true;
            this.cboSchool26.Location = new System.Drawing.Point(241, 275);
            this.cboSchool26.Name = "cboSchool26";
            this.cboSchool26.Size = new System.Drawing.Size(95, 21);
            this.cboSchool26.TabIndex = 43;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(54, 20);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(35, 13);
            this.label39.TabIndex = 1;
            this.label39.Text = "Name";
            // 
            // cmdEnterData
            // 
            this.cmdEnterData.Location = new System.Drawing.Point(292, 41);
            this.cmdEnterData.Name = "cmdEnterData";
            this.cmdEnterData.Size = new System.Drawing.Size(132, 54);
            this.cmdEnterData.TabIndex = 10;
            this.cmdEnterData.Text = "Enter Data";
            this.cmdEnterData.UseVisualStyleBackColor = true;
            this.cmdEnterData.Click += new System.EventHandler(this.cmdEnterData_Click);
            // 
            // cmdNext
            // 
            this.cmdNext.Location = new System.Drawing.Point(154, 41);
            this.cmdNext.Name = "cmdNext";
            this.cmdNext.Size = new System.Drawing.Size(132, 54);
            this.cmdNext.TabIndex = 9;
            this.cmdNext.Text = "Next Flight";
            this.cmdNext.UseVisualStyleBackColor = true;
            this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
            // 
            // cmdPrevious
            // 
            this.cmdPrevious.Location = new System.Drawing.Point(12, 41);
            this.cmdPrevious.Name = "cmdPrevious";
            this.cmdPrevious.Size = new System.Drawing.Size(132, 54);
            this.cmdPrevious.TabIndex = 8;
            this.cmdPrevious.Text = "Previous Flight";
            this.cmdPrevious.UseVisualStyleBackColor = true;
            this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "School";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Place";
            // 
            // grpHeats1
            // 
            this.grpHeats1.Controls.Add(this.cboSchool16);
            this.grpHeats1.Controls.Add(this.txtPerf16);
            this.grpHeats1.Controls.Add(this.txtName16);
            this.grpHeats1.Controls.Add(this.lblPlace16);
            this.grpHeats1.Controls.Add(this.cboSchool15);
            this.grpHeats1.Controls.Add(this.txtPerf15);
            this.grpHeats1.Controls.Add(this.txtName15);
            this.grpHeats1.Controls.Add(this.lblPlace15);
            this.grpHeats1.Controls.Add(this.cboSchool14);
            this.grpHeats1.Controls.Add(this.txtPerf14);
            this.grpHeats1.Controls.Add(this.txtName14);
            this.grpHeats1.Controls.Add(this.lblPlace14);
            this.grpHeats1.Controls.Add(this.cboSchool13);
            this.grpHeats1.Controls.Add(this.txtPerf13);
            this.grpHeats1.Controls.Add(this.txtName13);
            this.grpHeats1.Controls.Add(this.lblPlace13);
            this.grpHeats1.Controls.Add(this.cboSchool12);
            this.grpHeats1.Controls.Add(this.txtPerf12);
            this.grpHeats1.Controls.Add(this.txtName12);
            this.grpHeats1.Controls.Add(this.lblPlace12);
            this.grpHeats1.Controls.Add(this.cboSchool11);
            this.grpHeats1.Controls.Add(this.txtPerf11);
            this.grpHeats1.Controls.Add(this.txtName11);
            this.grpHeats1.Controls.Add(this.lblPlace11);
            this.grpHeats1.Controls.Add(this.cboSchool10);
            this.grpHeats1.Controls.Add(this.txtPerf10);
            this.grpHeats1.Controls.Add(this.txtName10);
            this.grpHeats1.Controls.Add(this.lblPlace10);
            this.grpHeats1.Controls.Add(this.cboSchool9);
            this.grpHeats1.Controls.Add(this.txtPerf9);
            this.grpHeats1.Controls.Add(this.txtName9);
            this.grpHeats1.Controls.Add(this.lblPlace9);
            this.grpHeats1.Controls.Add(this.cboSchool8);
            this.grpHeats1.Controls.Add(this.txtPerf8);
            this.grpHeats1.Controls.Add(this.txtName8);
            this.grpHeats1.Controls.Add(this.lblPlace8);
            this.grpHeats1.Controls.Add(this.cboSchool7);
            this.grpHeats1.Controls.Add(this.txtPerf7);
            this.grpHeats1.Controls.Add(this.txtName7);
            this.grpHeats1.Controls.Add(this.lblPlace7);
            this.grpHeats1.Controls.Add(this.cboSchool6);
            this.grpHeats1.Controls.Add(this.txtPerf6);
            this.grpHeats1.Controls.Add(this.txtName6);
            this.grpHeats1.Controls.Add(this.lblPlace6);
            this.grpHeats1.Controls.Add(this.cboSchool5);
            this.grpHeats1.Controls.Add(this.txtPerf5);
            this.grpHeats1.Controls.Add(this.txtName5);
            this.grpHeats1.Controls.Add(this.lblPlace5);
            this.grpHeats1.Controls.Add(this.cboSchool4);
            this.grpHeats1.Controls.Add(this.txtPerf4);
            this.grpHeats1.Controls.Add(this.txtName4);
            this.grpHeats1.Controls.Add(this.lblPlace4);
            this.grpHeats1.Controls.Add(this.cboSchool3);
            this.grpHeats1.Controls.Add(this.txtPerf3);
            this.grpHeats1.Controls.Add(this.txtName3);
            this.grpHeats1.Controls.Add(this.lblPlace3);
            this.grpHeats1.Controls.Add(this.cboSchool2);
            this.grpHeats1.Controls.Add(this.txtPerf2);
            this.grpHeats1.Controls.Add(this.txtName2);
            this.grpHeats1.Controls.Add(this.lblPlace2);
            this.grpHeats1.Controls.Add(this.cboSchool1);
            this.grpHeats1.Controls.Add(this.txtPerf1);
            this.grpHeats1.Controls.Add(this.txtName1);
            this.grpHeats1.Controls.Add(this.lblPlace1);
            this.grpHeats1.Controls.Add(this.label4);
            this.grpHeats1.Controls.Add(this.label3);
            this.grpHeats1.Controls.Add(this.label2);
            this.grpHeats1.Controls.Add(this.label1);
            this.grpHeats1.Location = new System.Drawing.Point(12, 101);
            this.grpHeats1.Name = "grpHeats1";
            this.grpHeats1.Size = new System.Drawing.Size(460, 465);
            this.grpHeats1.TabIndex = 7;
            this.grpHeats1.TabStop = false;
            this.grpHeats1.Text = "Flight #1";
            // 
            // mnuClearThis
            // 
            this.mnuClearThis.Name = "mnuClearThis";
            this.mnuClearThis.Size = new System.Drawing.Size(146, 22);
            this.mnuClearThis.Text = "Clear this flight";
            this.mnuClearThis.Click += new System.EventHandler(this.mnuClearThis_Click);
            // 
            // mnuClear
            // 
            this.mnuClear.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClearThis,
            this.mnuClearAll});
            this.mnuClear.Name = "mnuClear";
            this.mnuClear.Size = new System.Drawing.Size(44, 20);
            this.mnuClear.Text = "Clear";
            this.mnuClear.Click += new System.EventHandler(this.mnuClear_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(146, 22);
            this.mnuClearAll.Text = "Clear all flights";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuPrintout
            // 
            this.mnuPrintout.Name = "mnuPrintout";
            this.mnuPrintout.Size = new System.Drawing.Size(57, 20);
            this.mnuPrintout.Text = "Printout";
            this.mnuPrintout.Click += new System.EventHandler(this.mnuPrintout_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPrintout,
            this.mnuClear});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(992, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // FieldEventEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 573);
            this.Controls.Add(this.grpHeats2);
            this.Controls.Add(this.cmdEnterData);
            this.Controls.Add(this.cmdNext);
            this.Controls.Add(this.cmdPrevious);
            this.Controls.Add(this.grpHeats1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FieldEventEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FieldEventEntry";
            this.Load += new System.EventHandler(this.FieldEventEntry_Load);
            this.grpHeats2.ResumeLayout(false);
            this.grpHeats2.PerformLayout();
            this.grpHeats1.ResumeLayout(false);
            this.grpHeats1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboSchool16;
        private System.Windows.Forms.TextBox txtPerf16;
        private System.Windows.Forms.TextBox txtName16;
        private System.Windows.Forms.Label lblPlace16;
        private System.Windows.Forms.ComboBox cboSchool15;
        private System.Windows.Forms.TextBox txtPerf15;
        private System.Windows.Forms.TextBox txtName15;
        private System.Windows.Forms.Label lblPlace15;
        private System.Windows.Forms.ComboBox cboSchool14;
        private System.Windows.Forms.TextBox txtPerf14;
        private System.Windows.Forms.TextBox txtName14;
        private System.Windows.Forms.Label lblPlace14;
        private System.Windows.Forms.ComboBox cboSchool23;
        private System.Windows.Forms.TextBox txtPerf23;
        private System.Windows.Forms.TextBox txtName23;
        private System.Windows.Forms.Label lblPlace23;
        private System.Windows.Forms.ComboBox cboSchool22;
        private System.Windows.Forms.TextBox txtPerf22;
        private System.Windows.Forms.TextBox txtName22;
        private System.Windows.Forms.Label lblPlace22;
        private System.Windows.Forms.ComboBox cboSchool21;
        private System.Windows.Forms.TextBox txtPerf21;
        private System.Windows.Forms.ComboBox cboSchool13;
        private System.Windows.Forms.TextBox txtName21;
        private System.Windows.Forms.Label lblPlace21;
        private System.Windows.Forms.ComboBox cboSchool20;
        private System.Windows.Forms.TextBox txtPerf20;
        private System.Windows.Forms.TextBox txtName20;
        private System.Windows.Forms.Label lblPlace20;
        private System.Windows.Forms.ComboBox cboSchool19;
        private System.Windows.Forms.TextBox txtPerf19;
        private System.Windows.Forms.TextBox txtName19;
        private System.Windows.Forms.ComboBox cboSchool18;
        private System.Windows.Forms.TextBox txtPerf13;
        private System.Windows.Forms.TextBox txtName13;
        private System.Windows.Forms.Label lblPlace13;
        private System.Windows.Forms.ComboBox cboSchool12;
        private System.Windows.Forms.TextBox txtPerf12;
        private System.Windows.Forms.TextBox txtName12;
        private System.Windows.Forms.Label lblPlace12;
        private System.Windows.Forms.ComboBox cboSchool11;
        private System.Windows.Forms.TextBox txtPerf11;
        private System.Windows.Forms.TextBox txtName11;
        private System.Windows.Forms.Label lblPlace11;
        private System.Windows.Forms.ComboBox cboSchool10;
        private System.Windows.Forms.TextBox txtPerf10;
        private System.Windows.Forms.TextBox txtName10;
        private System.Windows.Forms.TextBox txtPerf26;
        private System.Windows.Forms.Label lblPlace26;
        private System.Windows.Forms.ComboBox cboSchool25;
        private System.Windows.Forms.TextBox txtPerf25;
        private System.Windows.Forms.TextBox txtName25;
        private System.Windows.Forms.Label lblPlace25;
        private System.Windows.Forms.ComboBox cboSchool24;
        private System.Windows.Forms.TextBox txtPerf24;
        private System.Windows.Forms.TextBox txtName24;
        private System.Windows.Forms.Label lblPlace24;
        private System.Windows.Forms.Label lblPlace19;
        private System.Windows.Forms.Label lblPlace10;
        private System.Windows.Forms.ComboBox cboSchool9;
        private System.Windows.Forms.TextBox txtPerf9;
        private System.Windows.Forms.TextBox txtName9;
        private System.Windows.Forms.Label lblPlace9;
        private System.Windows.Forms.ComboBox cboSchool8;
        private System.Windows.Forms.TextBox txtPerf8;
        private System.Windows.Forms.TextBox txtName8;
        private System.Windows.Forms.Label lblPlace8;
        private System.Windows.Forms.ComboBox cboSchool7;
        private System.Windows.Forms.TextBox txtPerf7;
        private System.Windows.Forms.TextBox txtName7;
        private System.Windows.Forms.Label lblPlace7;
        private System.Windows.Forms.ComboBox cboSchool6;
        private System.Windows.Forms.TextBox txtPerf6;
        private System.Windows.Forms.TextBox txtName6;
        private System.Windows.Forms.TextBox txtName26;
        private System.Windows.Forms.TextBox txtPerf18;
        private System.Windows.Forms.TextBox txtName18;
        private System.Windows.Forms.Label lblPlace18;
        private System.Windows.Forms.ComboBox cboSchool17;
        private System.Windows.Forms.TextBox txtPerf17;
        private System.Windows.Forms.TextBox txtName17;
        private System.Windows.Forms.Label lblPlace17;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label lblPlace6;
        private System.Windows.Forms.ComboBox cboSchool5;
        private System.Windows.Forms.TextBox txtPerf5;
        private System.Windows.Forms.TextBox txtName5;
        private System.Windows.Forms.Label lblPlace5;
        private System.Windows.Forms.ComboBox cboSchool4;
        private System.Windows.Forms.TextBox txtPerf4;
        private System.Windows.Forms.TextBox txtName4;
        private System.Windows.Forms.Label lblPlace4;
        private System.Windows.Forms.ComboBox cboSchool3;
        private System.Windows.Forms.TextBox txtPerf3;
        private System.Windows.Forms.TextBox txtName3;
        private System.Windows.Forms.Label lblPlace3;
        private System.Windows.Forms.ComboBox cboSchool2;
        private System.Windows.Forms.TextBox txtPerf2;
        private System.Windows.Forms.TextBox txtName2;
        private System.Windows.Forms.Label lblPlace2;
        private System.Windows.Forms.ComboBox cboSchool1;
        private System.Windows.Forms.TextBox txtPerf1;
        private System.Windows.Forms.TextBox txtName1;
        private System.Windows.Forms.Label lblPlace1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPerf32;
        private System.Windows.Forms.GroupBox grpHeats2;
        private System.Windows.Forms.ComboBox cboSchool32;
        private System.Windows.Forms.TextBox txtName32;
        private System.Windows.Forms.Label lblPlace32;
        private System.Windows.Forms.ComboBox cboSchool31;
        private System.Windows.Forms.TextBox txtPerf31;
        private System.Windows.Forms.TextBox txtName31;
        private System.Windows.Forms.Label lblPlace31;
        private System.Windows.Forms.ComboBox cboSchool30;
        private System.Windows.Forms.TextBox txtPerf30;
        private System.Windows.Forms.TextBox txtName30;
        private System.Windows.Forms.Label lblPlace30;
        private System.Windows.Forms.ComboBox cboSchool29;
        private System.Windows.Forms.TextBox txtPerf29;
        private System.Windows.Forms.TextBox txtName29;
        private System.Windows.Forms.Label lblPlace29;
        private System.Windows.Forms.ComboBox cboSchool28;
        private System.Windows.Forms.TextBox txtPerf28;
        private System.Windows.Forms.TextBox txtName28;
        private System.Windows.Forms.Label lblPlace28;
        private System.Windows.Forms.ComboBox cboSchool27;
        private System.Windows.Forms.TextBox txtPerf27;
        private System.Windows.Forms.TextBox txtName27;
        private System.Windows.Forms.Label lblPlace27;
        private System.Windows.Forms.ComboBox cboSchool26;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button cmdEnterData;
        private System.Windows.Forms.Button cmdNext;
        private System.Windows.Forms.Button cmdPrevious;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpHeats1;
        private System.Windows.Forms.ToolStripMenuItem mnuClearThis;
        private System.Windows.Forms.ToolStripMenuItem mnuClear;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuPrintout;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}