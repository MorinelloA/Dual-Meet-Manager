﻿namespace DualMeetManager.Presentation
{
    partial class RelayEventEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboSchool23 = new System.Windows.Forms.ComboBox();
            this.txtPerf23 = new System.Windows.Forms.TextBox();
            this.txtName23 = new System.Windows.Forms.TextBox();
            this.cboSchool22 = new System.Windows.Forms.ComboBox();
            this.txtPerf22 = new System.Windows.Forms.TextBox();
            this.txtName22 = new System.Windows.Forms.TextBox();
            this.cboSchool21 = new System.Windows.Forms.ComboBox();
            this.txtPerf21 = new System.Windows.Forms.TextBox();
            this.txtName21 = new System.Windows.Forms.TextBox();
            this.cboSchool20 = new System.Windows.Forms.ComboBox();
            this.txtPerf20 = new System.Windows.Forms.TextBox();
            this.txtName20 = new System.Windows.Forms.TextBox();
            this.cboSchool19 = new System.Windows.Forms.ComboBox();
            this.txtPerf19 = new System.Windows.Forms.TextBox();
            this.txtName19 = new System.Windows.Forms.TextBox();
            this.cboSchool18 = new System.Windows.Forms.ComboBox();
            this.txtPerf26 = new System.Windows.Forms.TextBox();
            this.cboSchool25 = new System.Windows.Forms.ComboBox();
            this.txtPerf25 = new System.Windows.Forms.TextBox();
            this.txtName25 = new System.Windows.Forms.TextBox();
            this.cboSchool24 = new System.Windows.Forms.ComboBox();
            this.txtPerf24 = new System.Windows.Forms.TextBox();
            this.txtName24 = new System.Windows.Forms.TextBox();
            this.cboSchool6 = new System.Windows.Forms.ComboBox();
            this.txtPerf6 = new System.Windows.Forms.TextBox();
            this.txtName6 = new System.Windows.Forms.TextBox();
            this.txtName26 = new System.Windows.Forms.TextBox();
            this.txtPerf18 = new System.Windows.Forms.TextBox();
            this.txtName18 = new System.Windows.Forms.TextBox();
            this.cboSchool17 = new System.Windows.Forms.ComboBox();
            this.txtPerf17 = new System.Windows.Forms.TextBox();
            this.txtName17 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.cboSchool5 = new System.Windows.Forms.ComboBox();
            this.txtPerf5 = new System.Windows.Forms.TextBox();
            this.txtName5 = new System.Windows.Forms.TextBox();
            this.cboSchool4 = new System.Windows.Forms.ComboBox();
            this.txtPerf4 = new System.Windows.Forms.TextBox();
            this.txtName4 = new System.Windows.Forms.TextBox();
            this.cboSchool3 = new System.Windows.Forms.ComboBox();
            this.txtPerf3 = new System.Windows.Forms.TextBox();
            this.txtName3 = new System.Windows.Forms.TextBox();
            this.cboSchool2 = new System.Windows.Forms.ComboBox();
            this.txtPerf2 = new System.Windows.Forms.TextBox();
            this.txtName2 = new System.Windows.Forms.TextBox();
            this.cboSchool1 = new System.Windows.Forms.ComboBox();
            this.txtPerf1 = new System.Windows.Forms.TextBox();
            this.txtName1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPerf32 = new System.Windows.Forms.TextBox();
            this.grpHeats2 = new System.Windows.Forms.GroupBox();
            this.cboSchool32 = new System.Windows.Forms.ComboBox();
            this.txtName32 = new System.Windows.Forms.TextBox();
            this.cboSchool31 = new System.Windows.Forms.ComboBox();
            this.txtPerf31 = new System.Windows.Forms.TextBox();
            this.txtName31 = new System.Windows.Forms.TextBox();
            this.cboSchool30 = new System.Windows.Forms.ComboBox();
            this.txtPerf30 = new System.Windows.Forms.TextBox();
            this.txtName30 = new System.Windows.Forms.TextBox();
            this.cboSchool29 = new System.Windows.Forms.ComboBox();
            this.txtPerf29 = new System.Windows.Forms.TextBox();
            this.txtName29 = new System.Windows.Forms.TextBox();
            this.cboSchool28 = new System.Windows.Forms.ComboBox();
            this.txtPerf28 = new System.Windows.Forms.TextBox();
            this.txtName28 = new System.Windows.Forms.TextBox();
            this.cboSchool27 = new System.Windows.Forms.ComboBox();
            this.txtPerf27 = new System.Windows.Forms.TextBox();
            this.txtName27 = new System.Windows.Forms.TextBox();
            this.cboSchool26 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.cmdEnterData = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpHeats1 = new System.Windows.Forms.GroupBox();
            this.mnuClear = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrintout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.grpHeats2.SuspendLayout();
            this.grpHeats1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboSchool23
            // 
            this.cboSchool23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool23.FormattingEnabled = true;
            this.cboSchool23.Location = new System.Drawing.Point(198, 197);
            this.cboSchool23.Name = "cboSchool23";
            this.cboSchool23.Size = new System.Drawing.Size(95, 21);
            this.cboSchool23.TabIndex = 31;
            // 
            // txtPerf23
            // 
            this.txtPerf23.Location = new System.Drawing.Point(303, 197);
            this.txtPerf23.Name = "txtPerf23";
            this.txtPerf23.Size = new System.Drawing.Size(100, 20);
            this.txtPerf23.TabIndex = 30;
            // 
            // txtName23
            // 
            this.txtName23.Location = new System.Drawing.Point(14, 197);
            this.txtName23.Name = "txtName23";
            this.txtName23.Size = new System.Drawing.Size(168, 20);
            this.txtName23.TabIndex = 29;
            // 
            // cboSchool22
            // 
            this.cboSchool22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool22.FormattingEnabled = true;
            this.cboSchool22.Location = new System.Drawing.Point(198, 171);
            this.cboSchool22.Name = "cboSchool22";
            this.cboSchool22.Size = new System.Drawing.Size(95, 21);
            this.cboSchool22.TabIndex = 27;
            // 
            // txtPerf22
            // 
            this.txtPerf22.Location = new System.Drawing.Point(303, 171);
            this.txtPerf22.Name = "txtPerf22";
            this.txtPerf22.Size = new System.Drawing.Size(100, 20);
            this.txtPerf22.TabIndex = 26;
            // 
            // txtName22
            // 
            this.txtName22.Location = new System.Drawing.Point(14, 171);
            this.txtName22.Name = "txtName22";
            this.txtName22.Size = new System.Drawing.Size(168, 20);
            this.txtName22.TabIndex = 25;
            // 
            // cboSchool21
            // 
            this.cboSchool21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool21.FormattingEnabled = true;
            this.cboSchool21.Location = new System.Drawing.Point(198, 145);
            this.cboSchool21.Name = "cboSchool21";
            this.cboSchool21.Size = new System.Drawing.Size(95, 21);
            this.cboSchool21.TabIndex = 23;
            // 
            // txtPerf21
            // 
            this.txtPerf21.Location = new System.Drawing.Point(303, 145);
            this.txtPerf21.Name = "txtPerf21";
            this.txtPerf21.Size = new System.Drawing.Size(100, 20);
            this.txtPerf21.TabIndex = 22;
            // 
            // txtName21
            // 
            this.txtName21.Location = new System.Drawing.Point(14, 145);
            this.txtName21.Name = "txtName21";
            this.txtName21.Size = new System.Drawing.Size(168, 20);
            this.txtName21.TabIndex = 21;
            // 
            // cboSchool20
            // 
            this.cboSchool20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool20.FormattingEnabled = true;
            this.cboSchool20.Location = new System.Drawing.Point(198, 119);
            this.cboSchool20.Name = "cboSchool20";
            this.cboSchool20.Size = new System.Drawing.Size(95, 21);
            this.cboSchool20.TabIndex = 19;
            // 
            // txtPerf20
            // 
            this.txtPerf20.Location = new System.Drawing.Point(303, 119);
            this.txtPerf20.Name = "txtPerf20";
            this.txtPerf20.Size = new System.Drawing.Size(100, 20);
            this.txtPerf20.TabIndex = 18;
            // 
            // txtName20
            // 
            this.txtName20.Location = new System.Drawing.Point(14, 119);
            this.txtName20.Name = "txtName20";
            this.txtName20.Size = new System.Drawing.Size(168, 20);
            this.txtName20.TabIndex = 17;
            // 
            // cboSchool19
            // 
            this.cboSchool19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool19.FormattingEnabled = true;
            this.cboSchool19.Location = new System.Drawing.Point(198, 93);
            this.cboSchool19.Name = "cboSchool19";
            this.cboSchool19.Size = new System.Drawing.Size(95, 21);
            this.cboSchool19.TabIndex = 15;
            // 
            // txtPerf19
            // 
            this.txtPerf19.Location = new System.Drawing.Point(303, 93);
            this.txtPerf19.Name = "txtPerf19";
            this.txtPerf19.Size = new System.Drawing.Size(100, 20);
            this.txtPerf19.TabIndex = 14;
            // 
            // txtName19
            // 
            this.txtName19.Location = new System.Drawing.Point(14, 93);
            this.txtName19.Name = "txtName19";
            this.txtName19.Size = new System.Drawing.Size(168, 20);
            this.txtName19.TabIndex = 13;
            // 
            // cboSchool18
            // 
            this.cboSchool18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool18.FormattingEnabled = true;
            this.cboSchool18.Location = new System.Drawing.Point(198, 67);
            this.cboSchool18.Name = "cboSchool18";
            this.cboSchool18.Size = new System.Drawing.Size(95, 21);
            this.cboSchool18.TabIndex = 11;
            // 
            // txtPerf26
            // 
            this.txtPerf26.Location = new System.Drawing.Point(303, 275);
            this.txtPerf26.Name = "txtPerf26";
            this.txtPerf26.Size = new System.Drawing.Size(100, 20);
            this.txtPerf26.TabIndex = 42;
            // 
            // cboSchool25
            // 
            this.cboSchool25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool25.FormattingEnabled = true;
            this.cboSchool25.Location = new System.Drawing.Point(198, 249);
            this.cboSchool25.Name = "cboSchool25";
            this.cboSchool25.Size = new System.Drawing.Size(95, 21);
            this.cboSchool25.TabIndex = 39;
            // 
            // txtPerf25
            // 
            this.txtPerf25.Location = new System.Drawing.Point(303, 249);
            this.txtPerf25.Name = "txtPerf25";
            this.txtPerf25.Size = new System.Drawing.Size(100, 20);
            this.txtPerf25.TabIndex = 38;
            // 
            // txtName25
            // 
            this.txtName25.Location = new System.Drawing.Point(14, 249);
            this.txtName25.Name = "txtName25";
            this.txtName25.Size = new System.Drawing.Size(168, 20);
            this.txtName25.TabIndex = 37;
            // 
            // cboSchool24
            // 
            this.cboSchool24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool24.FormattingEnabled = true;
            this.cboSchool24.Location = new System.Drawing.Point(198, 223);
            this.cboSchool24.Name = "cboSchool24";
            this.cboSchool24.Size = new System.Drawing.Size(95, 21);
            this.cboSchool24.TabIndex = 35;
            // 
            // txtPerf24
            // 
            this.txtPerf24.Location = new System.Drawing.Point(303, 223);
            this.txtPerf24.Name = "txtPerf24";
            this.txtPerf24.Size = new System.Drawing.Size(100, 20);
            this.txtPerf24.TabIndex = 34;
            // 
            // txtName24
            // 
            this.txtName24.Location = new System.Drawing.Point(14, 223);
            this.txtName24.Name = "txtName24";
            this.txtName24.Size = new System.Drawing.Size(168, 20);
            this.txtName24.TabIndex = 33;
            // 
            // cboSchool6
            // 
            this.cboSchool6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool6.FormattingEnabled = true;
            this.cboSchool6.Location = new System.Drawing.Point(201, 171);
            this.cboSchool6.Name = "cboSchool6";
            this.cboSchool6.Size = new System.Drawing.Size(95, 21);
            this.cboSchool6.TabIndex = 27;
            this.cboSchool6.SelectedIndexChanged += new System.EventHandler(this.cboSchool6_SelectedIndexChanged);
            // 
            // txtPerf6
            // 
            this.txtPerf6.Location = new System.Drawing.Point(306, 171);
            this.txtPerf6.Name = "txtPerf6";
            this.txtPerf6.Size = new System.Drawing.Size(100, 20);
            this.txtPerf6.TabIndex = 26;
            // 
            // txtName6
            // 
            this.txtName6.Location = new System.Drawing.Point(17, 171);
            this.txtName6.Name = "txtName6";
            this.txtName6.ReadOnly = true;
            this.txtName6.Size = new System.Drawing.Size(168, 20);
            this.txtName6.TabIndex = 25;
            // 
            // txtName26
            // 
            this.txtName26.Location = new System.Drawing.Point(14, 275);
            this.txtName26.Name = "txtName26";
            this.txtName26.Size = new System.Drawing.Size(168, 20);
            this.txtName26.TabIndex = 41;
            // 
            // txtPerf18
            // 
            this.txtPerf18.Location = new System.Drawing.Point(303, 67);
            this.txtPerf18.Name = "txtPerf18";
            this.txtPerf18.Size = new System.Drawing.Size(100, 20);
            this.txtPerf18.TabIndex = 10;
            // 
            // txtName18
            // 
            this.txtName18.Location = new System.Drawing.Point(14, 67);
            this.txtName18.Name = "txtName18";
            this.txtName18.Size = new System.Drawing.Size(168, 20);
            this.txtName18.TabIndex = 9;
            // 
            // cboSchool17
            // 
            this.cboSchool17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool17.FormattingEnabled = true;
            this.cboSchool17.Location = new System.Drawing.Point(198, 41);
            this.cboSchool17.Name = "cboSchool17";
            this.cboSchool17.Size = new System.Drawing.Size(95, 21);
            this.cboSchool17.TabIndex = 7;
            // 
            // txtPerf17
            // 
            this.txtPerf17.Location = new System.Drawing.Point(303, 41);
            this.txtPerf17.Name = "txtPerf17";
            this.txtPerf17.Size = new System.Drawing.Size(100, 20);
            this.txtPerf17.TabIndex = 6;
            // 
            // txtName17
            // 
            this.txtName17.Location = new System.Drawing.Point(14, 41);
            this.txtName17.Name = "txtName17";
            this.txtName17.Size = new System.Drawing.Size(168, 20);
            this.txtName17.TabIndex = 5;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(316, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Time";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(211, 20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "School";
            // 
            // cboSchool5
            // 
            this.cboSchool5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool5.FormattingEnabled = true;
            this.cboSchool5.Location = new System.Drawing.Point(201, 145);
            this.cboSchool5.Name = "cboSchool5";
            this.cboSchool5.Size = new System.Drawing.Size(95, 21);
            this.cboSchool5.TabIndex = 23;
            this.cboSchool5.SelectedIndexChanged += new System.EventHandler(this.cboSchool5_SelectedIndexChanged);
            // 
            // txtPerf5
            // 
            this.txtPerf5.Location = new System.Drawing.Point(306, 145);
            this.txtPerf5.Name = "txtPerf5";
            this.txtPerf5.Size = new System.Drawing.Size(100, 20);
            this.txtPerf5.TabIndex = 22;
            // 
            // txtName5
            // 
            this.txtName5.Location = new System.Drawing.Point(17, 145);
            this.txtName5.Name = "txtName5";
            this.txtName5.ReadOnly = true;
            this.txtName5.Size = new System.Drawing.Size(168, 20);
            this.txtName5.TabIndex = 21;
            // 
            // cboSchool4
            // 
            this.cboSchool4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool4.FormattingEnabled = true;
            this.cboSchool4.Location = new System.Drawing.Point(201, 119);
            this.cboSchool4.Name = "cboSchool4";
            this.cboSchool4.Size = new System.Drawing.Size(95, 21);
            this.cboSchool4.TabIndex = 19;
            this.cboSchool4.SelectedIndexChanged += new System.EventHandler(this.cboSchool4_SelectedIndexChanged);
            // 
            // txtPerf4
            // 
            this.txtPerf4.Location = new System.Drawing.Point(306, 119);
            this.txtPerf4.Name = "txtPerf4";
            this.txtPerf4.Size = new System.Drawing.Size(100, 20);
            this.txtPerf4.TabIndex = 18;
            // 
            // txtName4
            // 
            this.txtName4.Location = new System.Drawing.Point(17, 119);
            this.txtName4.Name = "txtName4";
            this.txtName4.ReadOnly = true;
            this.txtName4.Size = new System.Drawing.Size(168, 20);
            this.txtName4.TabIndex = 17;
            // 
            // cboSchool3
            // 
            this.cboSchool3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool3.FormattingEnabled = true;
            this.cboSchool3.Location = new System.Drawing.Point(201, 93);
            this.cboSchool3.Name = "cboSchool3";
            this.cboSchool3.Size = new System.Drawing.Size(95, 21);
            this.cboSchool3.TabIndex = 15;
            this.cboSchool3.SelectedIndexChanged += new System.EventHandler(this.cboSchool3_SelectedIndexChanged);
            // 
            // txtPerf3
            // 
            this.txtPerf3.Location = new System.Drawing.Point(306, 93);
            this.txtPerf3.Name = "txtPerf3";
            this.txtPerf3.Size = new System.Drawing.Size(100, 20);
            this.txtPerf3.TabIndex = 14;
            // 
            // txtName3
            // 
            this.txtName3.Location = new System.Drawing.Point(17, 93);
            this.txtName3.Name = "txtName3";
            this.txtName3.ReadOnly = true;
            this.txtName3.Size = new System.Drawing.Size(168, 20);
            this.txtName3.TabIndex = 13;
            // 
            // cboSchool2
            // 
            this.cboSchool2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool2.FormattingEnabled = true;
            this.cboSchool2.Location = new System.Drawing.Point(201, 67);
            this.cboSchool2.Name = "cboSchool2";
            this.cboSchool2.Size = new System.Drawing.Size(95, 21);
            this.cboSchool2.TabIndex = 11;
            this.cboSchool2.SelectedIndexChanged += new System.EventHandler(this.cboSchool2_SelectedIndexChanged);
            // 
            // txtPerf2
            // 
            this.txtPerf2.Location = new System.Drawing.Point(306, 67);
            this.txtPerf2.Name = "txtPerf2";
            this.txtPerf2.Size = new System.Drawing.Size(100, 20);
            this.txtPerf2.TabIndex = 10;
            // 
            // txtName2
            // 
            this.txtName2.Location = new System.Drawing.Point(17, 67);
            this.txtName2.Name = "txtName2";
            this.txtName2.ReadOnly = true;
            this.txtName2.Size = new System.Drawing.Size(168, 20);
            this.txtName2.TabIndex = 9;
            // 
            // cboSchool1
            // 
            this.cboSchool1.BackColor = System.Drawing.SystemColors.Window;
            this.cboSchool1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool1.FormattingEnabled = true;
            this.cboSchool1.Location = new System.Drawing.Point(201, 41);
            this.cboSchool1.Name = "cboSchool1";
            this.cboSchool1.Size = new System.Drawing.Size(95, 21);
            this.cboSchool1.TabIndex = 7;
            this.cboSchool1.SelectedIndexChanged += new System.EventHandler(this.cboSchool1_SelectedIndexChanged);
            // 
            // txtPerf1
            // 
            this.txtPerf1.Location = new System.Drawing.Point(306, 41);
            this.txtPerf1.Name = "txtPerf1";
            this.txtPerf1.Size = new System.Drawing.Size(100, 20);
            this.txtPerf1.TabIndex = 6;
            // 
            // txtName1
            // 
            this.txtName1.Location = new System.Drawing.Point(17, 41);
            this.txtName1.Name = "txtName1";
            this.txtName1.ReadOnly = true;
            this.txtName1.Size = new System.Drawing.Size(168, 20);
            this.txtName1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(319, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Time";
            // 
            // txtPerf32
            // 
            this.txtPerf32.Location = new System.Drawing.Point(303, 431);
            this.txtPerf32.Name = "txtPerf32";
            this.txtPerf32.Size = new System.Drawing.Size(100, 20);
            this.txtPerf32.TabIndex = 66;
            // 
            // grpHeats2
            // 
            this.grpHeats2.Controls.Add(this.cboSchool32);
            this.grpHeats2.Controls.Add(this.txtPerf32);
            this.grpHeats2.Controls.Add(this.txtName32);
            this.grpHeats2.Controls.Add(this.cboSchool31);
            this.grpHeats2.Controls.Add(this.txtPerf31);
            this.grpHeats2.Controls.Add(this.txtName31);
            this.grpHeats2.Controls.Add(this.cboSchool30);
            this.grpHeats2.Controls.Add(this.txtPerf30);
            this.grpHeats2.Controls.Add(this.txtName30);
            this.grpHeats2.Controls.Add(this.cboSchool29);
            this.grpHeats2.Controls.Add(this.txtPerf29);
            this.grpHeats2.Controls.Add(this.txtName29);
            this.grpHeats2.Controls.Add(this.cboSchool28);
            this.grpHeats2.Controls.Add(this.txtPerf28);
            this.grpHeats2.Controls.Add(this.txtName28);
            this.grpHeats2.Controls.Add(this.cboSchool27);
            this.grpHeats2.Controls.Add(this.txtPerf27);
            this.grpHeats2.Controls.Add(this.txtName27);
            this.grpHeats2.Controls.Add(this.cboSchool26);
            this.grpHeats2.Controls.Add(this.txtPerf26);
            this.grpHeats2.Controls.Add(this.txtName26);
            this.grpHeats2.Controls.Add(this.cboSchool25);
            this.grpHeats2.Controls.Add(this.txtPerf25);
            this.grpHeats2.Controls.Add(this.txtName25);
            this.grpHeats2.Controls.Add(this.cboSchool24);
            this.grpHeats2.Controls.Add(this.txtPerf24);
            this.grpHeats2.Controls.Add(this.txtName24);
            this.grpHeats2.Controls.Add(this.cboSchool23);
            this.grpHeats2.Controls.Add(this.txtPerf23);
            this.grpHeats2.Controls.Add(this.txtName23);
            this.grpHeats2.Controls.Add(this.cboSchool22);
            this.grpHeats2.Controls.Add(this.txtPerf22);
            this.grpHeats2.Controls.Add(this.txtName22);
            this.grpHeats2.Controls.Add(this.cboSchool21);
            this.grpHeats2.Controls.Add(this.txtPerf21);
            this.grpHeats2.Controls.Add(this.txtName21);
            this.grpHeats2.Controls.Add(this.cboSchool20);
            this.grpHeats2.Controls.Add(this.txtPerf20);
            this.grpHeats2.Controls.Add(this.txtName20);
            this.grpHeats2.Controls.Add(this.cboSchool19);
            this.grpHeats2.Controls.Add(this.txtPerf19);
            this.grpHeats2.Controls.Add(this.txtName19);
            this.grpHeats2.Controls.Add(this.cboSchool18);
            this.grpHeats2.Controls.Add(this.txtPerf18);
            this.grpHeats2.Controls.Add(this.txtName18);
            this.grpHeats2.Controls.Add(this.cboSchool17);
            this.grpHeats2.Controls.Add(this.txtPerf17);
            this.grpHeats2.Controls.Add(this.txtName17);
            this.grpHeats2.Controls.Add(this.label37);
            this.grpHeats2.Controls.Add(this.label38);
            this.grpHeats2.Controls.Add(this.label39);
            this.grpHeats2.Location = new System.Drawing.Point(443, 41);
            this.grpHeats2.Name = "grpHeats2";
            this.grpHeats2.Size = new System.Drawing.Size(417, 465);
            this.grpHeats2.TabIndex = 11;
            this.grpHeats2.TabStop = false;
            this.grpHeats2.Text = "Non-Scoring Relays";
            // 
            // cboSchool32
            // 
            this.cboSchool32.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool32.FormattingEnabled = true;
            this.cboSchool32.Location = new System.Drawing.Point(198, 431);
            this.cboSchool32.Name = "cboSchool32";
            this.cboSchool32.Size = new System.Drawing.Size(95, 21);
            this.cboSchool32.TabIndex = 67;
            // 
            // txtName32
            // 
            this.txtName32.Location = new System.Drawing.Point(14, 431);
            this.txtName32.Name = "txtName32";
            this.txtName32.Size = new System.Drawing.Size(168, 20);
            this.txtName32.TabIndex = 65;
            // 
            // cboSchool31
            // 
            this.cboSchool31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool31.FormattingEnabled = true;
            this.cboSchool31.Location = new System.Drawing.Point(198, 405);
            this.cboSchool31.Name = "cboSchool31";
            this.cboSchool31.Size = new System.Drawing.Size(95, 21);
            this.cboSchool31.TabIndex = 63;
            // 
            // txtPerf31
            // 
            this.txtPerf31.Location = new System.Drawing.Point(303, 405);
            this.txtPerf31.Name = "txtPerf31";
            this.txtPerf31.Size = new System.Drawing.Size(100, 20);
            this.txtPerf31.TabIndex = 62;
            // 
            // txtName31
            // 
            this.txtName31.Location = new System.Drawing.Point(14, 405);
            this.txtName31.Name = "txtName31";
            this.txtName31.Size = new System.Drawing.Size(168, 20);
            this.txtName31.TabIndex = 61;
            // 
            // cboSchool30
            // 
            this.cboSchool30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool30.FormattingEnabled = true;
            this.cboSchool30.Location = new System.Drawing.Point(198, 379);
            this.cboSchool30.Name = "cboSchool30";
            this.cboSchool30.Size = new System.Drawing.Size(95, 21);
            this.cboSchool30.TabIndex = 59;
            // 
            // txtPerf30
            // 
            this.txtPerf30.Location = new System.Drawing.Point(303, 379);
            this.txtPerf30.Name = "txtPerf30";
            this.txtPerf30.Size = new System.Drawing.Size(100, 20);
            this.txtPerf30.TabIndex = 58;
            // 
            // txtName30
            // 
            this.txtName30.Location = new System.Drawing.Point(14, 379);
            this.txtName30.Name = "txtName30";
            this.txtName30.Size = new System.Drawing.Size(168, 20);
            this.txtName30.TabIndex = 57;
            // 
            // cboSchool29
            // 
            this.cboSchool29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool29.FormattingEnabled = true;
            this.cboSchool29.Location = new System.Drawing.Point(198, 353);
            this.cboSchool29.Name = "cboSchool29";
            this.cboSchool29.Size = new System.Drawing.Size(95, 21);
            this.cboSchool29.TabIndex = 55;
            // 
            // txtPerf29
            // 
            this.txtPerf29.Location = new System.Drawing.Point(303, 353);
            this.txtPerf29.Name = "txtPerf29";
            this.txtPerf29.Size = new System.Drawing.Size(100, 20);
            this.txtPerf29.TabIndex = 54;
            // 
            // txtName29
            // 
            this.txtName29.Location = new System.Drawing.Point(14, 353);
            this.txtName29.Name = "txtName29";
            this.txtName29.Size = new System.Drawing.Size(168, 20);
            this.txtName29.TabIndex = 53;
            // 
            // cboSchool28
            // 
            this.cboSchool28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool28.FormattingEnabled = true;
            this.cboSchool28.Location = new System.Drawing.Point(198, 327);
            this.cboSchool28.Name = "cboSchool28";
            this.cboSchool28.Size = new System.Drawing.Size(95, 21);
            this.cboSchool28.TabIndex = 51;
            // 
            // txtPerf28
            // 
            this.txtPerf28.Location = new System.Drawing.Point(303, 327);
            this.txtPerf28.Name = "txtPerf28";
            this.txtPerf28.Size = new System.Drawing.Size(100, 20);
            this.txtPerf28.TabIndex = 50;
            // 
            // txtName28
            // 
            this.txtName28.Location = new System.Drawing.Point(14, 327);
            this.txtName28.Name = "txtName28";
            this.txtName28.Size = new System.Drawing.Size(168, 20);
            this.txtName28.TabIndex = 49;
            // 
            // cboSchool27
            // 
            this.cboSchool27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool27.FormattingEnabled = true;
            this.cboSchool27.Location = new System.Drawing.Point(198, 301);
            this.cboSchool27.Name = "cboSchool27";
            this.cboSchool27.Size = new System.Drawing.Size(95, 21);
            this.cboSchool27.TabIndex = 47;
            // 
            // txtPerf27
            // 
            this.txtPerf27.Location = new System.Drawing.Point(303, 301);
            this.txtPerf27.Name = "txtPerf27";
            this.txtPerf27.Size = new System.Drawing.Size(100, 20);
            this.txtPerf27.TabIndex = 46;
            // 
            // txtName27
            // 
            this.txtName27.Location = new System.Drawing.Point(14, 301);
            this.txtName27.Name = "txtName27";
            this.txtName27.Size = new System.Drawing.Size(168, 20);
            this.txtName27.TabIndex = 45;
            // 
            // cboSchool26
            // 
            this.cboSchool26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSchool26.FormattingEnabled = true;
            this.cboSchool26.Location = new System.Drawing.Point(198, 275);
            this.cboSchool26.Name = "cboSchool26";
            this.cboSchool26.Size = new System.Drawing.Size(95, 21);
            this.cboSchool26.TabIndex = 43;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(11, 20);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(35, 13);
            this.label39.TabIndex = 1;
            this.label39.Text = "Name";
            // 
            // cmdEnterData
            // 
            this.cmdEnterData.Location = new System.Drawing.Point(12, 41);
            this.cmdEnterData.Name = "cmdEnterData";
            this.cmdEnterData.Size = new System.Drawing.Size(421, 54);
            this.cmdEnterData.TabIndex = 10;
            this.cmdEnterData.Text = "Enter Data";
            this.cmdEnterData.UseVisualStyleBackColor = true;
            this.cmdEnterData.Click += new System.EventHandler(this.cmdEnterData_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "School";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // grpHeats1
            // 
            this.grpHeats1.Controls.Add(this.cboSchool6);
            this.grpHeats1.Controls.Add(this.txtPerf6);
            this.grpHeats1.Controls.Add(this.txtName6);
            this.grpHeats1.Controls.Add(this.cboSchool5);
            this.grpHeats1.Controls.Add(this.txtPerf5);
            this.grpHeats1.Controls.Add(this.txtName5);
            this.grpHeats1.Controls.Add(this.cboSchool4);
            this.grpHeats1.Controls.Add(this.txtPerf4);
            this.grpHeats1.Controls.Add(this.txtName4);
            this.grpHeats1.Controls.Add(this.cboSchool3);
            this.grpHeats1.Controls.Add(this.txtPerf3);
            this.grpHeats1.Controls.Add(this.txtName3);
            this.grpHeats1.Controls.Add(this.cboSchool2);
            this.grpHeats1.Controls.Add(this.txtPerf2);
            this.grpHeats1.Controls.Add(this.txtName2);
            this.grpHeats1.Controls.Add(this.cboSchool1);
            this.grpHeats1.Controls.Add(this.txtPerf1);
            this.grpHeats1.Controls.Add(this.txtName1);
            this.grpHeats1.Controls.Add(this.label4);
            this.grpHeats1.Controls.Add(this.label3);
            this.grpHeats1.Controls.Add(this.label2);
            this.grpHeats1.Location = new System.Drawing.Point(12, 101);
            this.grpHeats1.Name = "grpHeats1";
            this.grpHeats1.Size = new System.Drawing.Size(421, 203);
            this.grpHeats1.TabIndex = 7;
            this.grpHeats1.TabStop = false;
            this.grpHeats1.Text = "Scoring Relays";
            this.grpHeats1.Enter += new System.EventHandler(this.grpHeats1_Enter);
            // 
            // mnuClear
            // 
            this.mnuClear.Name = "mnuClear";
            this.mnuClear.Size = new System.Drawing.Size(44, 20);
            this.mnuClear.Text = "Clear";
            this.mnuClear.Click += new System.EventHandler(this.mnuClear_Click);
            // 
            // mnuPrintout
            // 
            this.mnuPrintout.Name = "mnuPrintout";
            this.mnuPrintout.Size = new System.Drawing.Size(57, 20);
            this.mnuPrintout.Text = "Printout";
            this.mnuPrintout.Click += new System.EventHandler(this.mnuPrintout_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPrintout,
            this.mnuClear});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(866, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // RelayEventEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 573);
            this.Controls.Add(this.grpHeats2);
            this.Controls.Add(this.cmdEnterData);
            this.Controls.Add(this.grpHeats1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "RelayEventEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RelayEventEntry";
            this.Load += new System.EventHandler(this.RelayEventEntry_Load);
            this.grpHeats2.ResumeLayout(false);
            this.grpHeats2.PerformLayout();
            this.grpHeats1.ResumeLayout(false);
            this.grpHeats1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cboSchool23;
        private System.Windows.Forms.TextBox txtPerf23;
        private System.Windows.Forms.TextBox txtName23;
        private System.Windows.Forms.ComboBox cboSchool22;
        private System.Windows.Forms.TextBox txtPerf22;
        private System.Windows.Forms.TextBox txtName22;
        private System.Windows.Forms.ComboBox cboSchool21;
        private System.Windows.Forms.TextBox txtPerf21;
        private System.Windows.Forms.TextBox txtName21;
        private System.Windows.Forms.ComboBox cboSchool20;
        private System.Windows.Forms.TextBox txtPerf20;
        private System.Windows.Forms.TextBox txtName20;
        private System.Windows.Forms.ComboBox cboSchool19;
        private System.Windows.Forms.TextBox txtPerf19;
        private System.Windows.Forms.TextBox txtName19;
        private System.Windows.Forms.ComboBox cboSchool18;
        private System.Windows.Forms.TextBox txtPerf26;
        private System.Windows.Forms.ComboBox cboSchool25;
        private System.Windows.Forms.TextBox txtPerf25;
        private System.Windows.Forms.TextBox txtName25;
        private System.Windows.Forms.ComboBox cboSchool24;
        private System.Windows.Forms.TextBox txtPerf24;
        private System.Windows.Forms.TextBox txtName24;
        private System.Windows.Forms.ComboBox cboSchool6;
        private System.Windows.Forms.TextBox txtPerf6;
        private System.Windows.Forms.TextBox txtName6;
        private System.Windows.Forms.TextBox txtName26;
        private System.Windows.Forms.TextBox txtPerf18;
        private System.Windows.Forms.TextBox txtName18;
        private System.Windows.Forms.ComboBox cboSchool17;
        private System.Windows.Forms.TextBox txtPerf17;
        private System.Windows.Forms.TextBox txtName17;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cboSchool5;
        private System.Windows.Forms.TextBox txtPerf5;
        private System.Windows.Forms.TextBox txtName5;
        private System.Windows.Forms.ComboBox cboSchool4;
        private System.Windows.Forms.TextBox txtPerf4;
        private System.Windows.Forms.TextBox txtName4;
        private System.Windows.Forms.ComboBox cboSchool3;
        private System.Windows.Forms.TextBox txtPerf3;
        private System.Windows.Forms.TextBox txtName3;
        private System.Windows.Forms.ComboBox cboSchool2;
        private System.Windows.Forms.TextBox txtPerf2;
        private System.Windows.Forms.TextBox txtName2;
        private System.Windows.Forms.ComboBox cboSchool1;
        private System.Windows.Forms.TextBox txtPerf1;
        private System.Windows.Forms.TextBox txtName1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPerf32;
        private System.Windows.Forms.GroupBox grpHeats2;
        private System.Windows.Forms.ComboBox cboSchool32;
        private System.Windows.Forms.TextBox txtName32;
        private System.Windows.Forms.ComboBox cboSchool31;
        private System.Windows.Forms.TextBox txtPerf31;
        private System.Windows.Forms.TextBox txtName31;
        private System.Windows.Forms.ComboBox cboSchool30;
        private System.Windows.Forms.TextBox txtPerf30;
        private System.Windows.Forms.TextBox txtName30;
        private System.Windows.Forms.ComboBox cboSchool29;
        private System.Windows.Forms.TextBox txtPerf29;
        private System.Windows.Forms.TextBox txtName29;
        private System.Windows.Forms.ComboBox cboSchool28;
        private System.Windows.Forms.TextBox txtPerf28;
        private System.Windows.Forms.TextBox txtName28;
        private System.Windows.Forms.ComboBox cboSchool27;
        private System.Windows.Forms.TextBox txtPerf27;
        private System.Windows.Forms.TextBox txtName27;
        private System.Windows.Forms.ComboBox cboSchool26;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button cmdEnterData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpHeats1;
        private System.Windows.Forms.ToolStripMenuItem mnuClear;
        private System.Windows.Forms.ToolStripMenuItem mnuPrintout;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}