﻿namespace DualMeetManager.Service
{
	/// <summary>
    /// Marker interface allows all classes in tiers
	/// </summary>
	public interface IService { }
}
