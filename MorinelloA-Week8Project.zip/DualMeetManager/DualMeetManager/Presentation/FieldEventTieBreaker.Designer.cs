﻿namespace DualMeetManager.Presentation
{
    partial class FieldEventTieBreaker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpPerformances = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblSchool16 = new System.Windows.Forms.Label();
            this.lblSchool15 = new System.Windows.Forms.Label();
            this.lblSchool14 = new System.Windows.Forms.Label();
            this.lblSchool13 = new System.Windows.Forms.Label();
            this.lblSchool12 = new System.Windows.Forms.Label();
            this.lblSchool11 = new System.Windows.Forms.Label();
            this.lblSchool10 = new System.Windows.Forms.Label();
            this.lblSchool9 = new System.Windows.Forms.Label();
            this.lblSchool8 = new System.Windows.Forms.Label();
            this.lblSchool7 = new System.Windows.Forms.Label();
            this.lblSchool6 = new System.Windows.Forms.Label();
            this.lblSchool5 = new System.Windows.Forms.Label();
            this.lblSchool4 = new System.Windows.Forms.Label();
            this.lblSchool3 = new System.Windows.Forms.Label();
            this.lblSchool2 = new System.Windows.Forms.Label();
            this.lblSchool1 = new System.Windows.Forms.Label();
            this.lblPerformance16 = new System.Windows.Forms.Label();
            this.lblPerformance15 = new System.Windows.Forms.Label();
            this.lblPerformance14 = new System.Windows.Forms.Label();
            this.lblPerformance13 = new System.Windows.Forms.Label();
            this.lblPerformance12 = new System.Windows.Forms.Label();
            this.lblPerformance11 = new System.Windows.Forms.Label();
            this.lblPerformance10 = new System.Windows.Forms.Label();
            this.lblPerformance9 = new System.Windows.Forms.Label();
            this.lblPerformance8 = new System.Windows.Forms.Label();
            this.lblPerformance7 = new System.Windows.Forms.Label();
            this.lblPerformance6 = new System.Windows.Forms.Label();
            this.lblPerformance5 = new System.Windows.Forms.Label();
            this.lblPerformance4 = new System.Windows.Forms.Label();
            this.lblPerformance3 = new System.Windows.Forms.Label();
            this.lblPerformance2 = new System.Windows.Forms.Label();
            this.lblPerformance1 = new System.Windows.Forms.Label();
            this.lblName16 = new System.Windows.Forms.Label();
            this.lblName15 = new System.Windows.Forms.Label();
            this.lblName14 = new System.Windows.Forms.Label();
            this.lblName13 = new System.Windows.Forms.Label();
            this.lblName12 = new System.Windows.Forms.Label();
            this.lblName11 = new System.Windows.Forms.Label();
            this.lblName10 = new System.Windows.Forms.Label();
            this.lblName9 = new System.Windows.Forms.Label();
            this.lblName8 = new System.Windows.Forms.Label();
            this.lblName7 = new System.Windows.Forms.Label();
            this.lblName6 = new System.Windows.Forms.Label();
            this.lblName5 = new System.Windows.Forms.Label();
            this.lblName4 = new System.Windows.Forms.Label();
            this.lblName3 = new System.Windows.Forms.Label();
            this.lblName2 = new System.Windows.Forms.Label();
            this.lblName1 = new System.Windows.Forms.Label();
            this.cboPlace16 = new System.Windows.Forms.ComboBox();
            this.cboPlace15 = new System.Windows.Forms.ComboBox();
            this.cboPlace14 = new System.Windows.Forms.ComboBox();
            this.cboPlace13 = new System.Windows.Forms.ComboBox();
            this.cboPlace12 = new System.Windows.Forms.ComboBox();
            this.cboPlace11 = new System.Windows.Forms.ComboBox();
            this.cboPlace10 = new System.Windows.Forms.ComboBox();
            this.cboPlace9 = new System.Windows.Forms.ComboBox();
            this.cboPlace8 = new System.Windows.Forms.ComboBox();
            this.cboPlace7 = new System.Windows.Forms.ComboBox();
            this.cboPlace6 = new System.Windows.Forms.ComboBox();
            this.cboPlace5 = new System.Windows.Forms.ComboBox();
            this.cboPlace4 = new System.Windows.Forms.ComboBox();
            this.cboPlace3 = new System.Windows.Forms.ComboBox();
            this.cboPlace2 = new System.Windows.Forms.ComboBox();
            this.cboPlace1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmdEnter = new System.Windows.Forms.Button();
            this.grpPerformances.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpPerformances
            // 
            this.grpPerformances.Controls.Add(this.label5);
            this.grpPerformances.Controls.Add(this.lblSchool16);
            this.grpPerformances.Controls.Add(this.lblSchool15);
            this.grpPerformances.Controls.Add(this.lblSchool14);
            this.grpPerformances.Controls.Add(this.lblSchool13);
            this.grpPerformances.Controls.Add(this.lblSchool12);
            this.grpPerformances.Controls.Add(this.lblSchool11);
            this.grpPerformances.Controls.Add(this.lblSchool10);
            this.grpPerformances.Controls.Add(this.lblSchool9);
            this.grpPerformances.Controls.Add(this.lblSchool8);
            this.grpPerformances.Controls.Add(this.lblSchool7);
            this.grpPerformances.Controls.Add(this.lblSchool6);
            this.grpPerformances.Controls.Add(this.lblSchool5);
            this.grpPerformances.Controls.Add(this.lblSchool4);
            this.grpPerformances.Controls.Add(this.lblSchool3);
            this.grpPerformances.Controls.Add(this.lblSchool2);
            this.grpPerformances.Controls.Add(this.lblSchool1);
            this.grpPerformances.Controls.Add(this.lblPerformance16);
            this.grpPerformances.Controls.Add(this.lblPerformance15);
            this.grpPerformances.Controls.Add(this.lblPerformance14);
            this.grpPerformances.Controls.Add(this.lblPerformance13);
            this.grpPerformances.Controls.Add(this.lblPerformance12);
            this.grpPerformances.Controls.Add(this.lblPerformance11);
            this.grpPerformances.Controls.Add(this.lblPerformance10);
            this.grpPerformances.Controls.Add(this.lblPerformance9);
            this.grpPerformances.Controls.Add(this.lblPerformance8);
            this.grpPerformances.Controls.Add(this.lblPerformance7);
            this.grpPerformances.Controls.Add(this.lblPerformance6);
            this.grpPerformances.Controls.Add(this.lblPerformance5);
            this.grpPerformances.Controls.Add(this.lblPerformance4);
            this.grpPerformances.Controls.Add(this.lblPerformance3);
            this.grpPerformances.Controls.Add(this.lblPerformance2);
            this.grpPerformances.Controls.Add(this.lblPerformance1);
            this.grpPerformances.Controls.Add(this.lblName16);
            this.grpPerformances.Controls.Add(this.lblName15);
            this.grpPerformances.Controls.Add(this.lblName14);
            this.grpPerformances.Controls.Add(this.lblName13);
            this.grpPerformances.Controls.Add(this.lblName12);
            this.grpPerformances.Controls.Add(this.lblName11);
            this.grpPerformances.Controls.Add(this.lblName10);
            this.grpPerformances.Controls.Add(this.lblName9);
            this.grpPerformances.Controls.Add(this.lblName8);
            this.grpPerformances.Controls.Add(this.lblName7);
            this.grpPerformances.Controls.Add(this.lblName6);
            this.grpPerformances.Controls.Add(this.lblName5);
            this.grpPerformances.Controls.Add(this.lblName4);
            this.grpPerformances.Controls.Add(this.lblName3);
            this.grpPerformances.Controls.Add(this.lblName2);
            this.grpPerformances.Controls.Add(this.lblName1);
            this.grpPerformances.Controls.Add(this.cboPlace16);
            this.grpPerformances.Controls.Add(this.cboPlace15);
            this.grpPerformances.Controls.Add(this.cboPlace14);
            this.grpPerformances.Controls.Add(this.cboPlace13);
            this.grpPerformances.Controls.Add(this.cboPlace12);
            this.grpPerformances.Controls.Add(this.cboPlace11);
            this.grpPerformances.Controls.Add(this.cboPlace10);
            this.grpPerformances.Controls.Add(this.cboPlace9);
            this.grpPerformances.Controls.Add(this.cboPlace8);
            this.grpPerformances.Controls.Add(this.cboPlace7);
            this.grpPerformances.Controls.Add(this.cboPlace6);
            this.grpPerformances.Controls.Add(this.cboPlace5);
            this.grpPerformances.Controls.Add(this.cboPlace4);
            this.grpPerformances.Controls.Add(this.cboPlace3);
            this.grpPerformances.Controls.Add(this.cboPlace2);
            this.grpPerformances.Controls.Add(this.cboPlace1);
            this.grpPerformances.Controls.Add(this.label4);
            this.grpPerformances.Controls.Add(this.label3);
            this.grpPerformances.Controls.Add(this.label2);
            this.grpPerformances.Location = new System.Drawing.Point(12, 63);
            this.grpPerformances.Name = "grpPerformances";
            this.grpPerformances.Size = new System.Drawing.Size(536, 467);
            this.grpPerformances.TabIndex = 8;
            this.grpPerformances.TabStop = false;
            this.grpPerformances.Text = "grpPerformances";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(432, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 115;
            this.label5.Text = "Place";
            // 
            // lblSchool16
            // 
            this.lblSchool16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool16.Location = new System.Drawing.Point(207, 434);
            this.lblSchool16.Name = "lblSchool16";
            this.lblSchool16.Size = new System.Drawing.Size(88, 20);
            this.lblSchool16.TabIndex = 114;
            this.lblSchool16.Visible = false;
            // 
            // lblSchool15
            // 
            this.lblSchool15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool15.Location = new System.Drawing.Point(207, 408);
            this.lblSchool15.Name = "lblSchool15";
            this.lblSchool15.Size = new System.Drawing.Size(88, 20);
            this.lblSchool15.TabIndex = 113;
            this.lblSchool15.Visible = false;
            // 
            // lblSchool14
            // 
            this.lblSchool14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool14.Location = new System.Drawing.Point(207, 381);
            this.lblSchool14.Name = "lblSchool14";
            this.lblSchool14.Size = new System.Drawing.Size(88, 20);
            this.lblSchool14.TabIndex = 112;
            this.lblSchool14.Visible = false;
            // 
            // lblSchool13
            // 
            this.lblSchool13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool13.Location = new System.Drawing.Point(207, 356);
            this.lblSchool13.Name = "lblSchool13";
            this.lblSchool13.Size = new System.Drawing.Size(88, 20);
            this.lblSchool13.TabIndex = 111;
            this.lblSchool13.Visible = false;
            // 
            // lblSchool12
            // 
            this.lblSchool12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool12.Location = new System.Drawing.Point(207, 330);
            this.lblSchool12.Name = "lblSchool12";
            this.lblSchool12.Size = new System.Drawing.Size(88, 20);
            this.lblSchool12.TabIndex = 110;
            this.lblSchool12.Visible = false;
            // 
            // lblSchool11
            // 
            this.lblSchool11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool11.Location = new System.Drawing.Point(207, 304);
            this.lblSchool11.Name = "lblSchool11";
            this.lblSchool11.Size = new System.Drawing.Size(88, 20);
            this.lblSchool11.TabIndex = 109;
            this.lblSchool11.Visible = false;
            // 
            // lblSchool10
            // 
            this.lblSchool10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool10.Location = new System.Drawing.Point(207, 277);
            this.lblSchool10.Name = "lblSchool10";
            this.lblSchool10.Size = new System.Drawing.Size(88, 20);
            this.lblSchool10.TabIndex = 108;
            this.lblSchool10.Visible = false;
            // 
            // lblSchool9
            // 
            this.lblSchool9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool9.Location = new System.Drawing.Point(207, 252);
            this.lblSchool9.Name = "lblSchool9";
            this.lblSchool9.Size = new System.Drawing.Size(88, 20);
            this.lblSchool9.TabIndex = 107;
            this.lblSchool9.Visible = false;
            // 
            // lblSchool8
            // 
            this.lblSchool8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool8.Location = new System.Drawing.Point(207, 226);
            this.lblSchool8.Name = "lblSchool8";
            this.lblSchool8.Size = new System.Drawing.Size(88, 20);
            this.lblSchool8.TabIndex = 106;
            this.lblSchool8.Visible = false;
            // 
            // lblSchool7
            // 
            this.lblSchool7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool7.Location = new System.Drawing.Point(207, 200);
            this.lblSchool7.Name = "lblSchool7";
            this.lblSchool7.Size = new System.Drawing.Size(88, 20);
            this.lblSchool7.TabIndex = 105;
            this.lblSchool7.Visible = false;
            // 
            // lblSchool6
            // 
            this.lblSchool6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool6.Location = new System.Drawing.Point(207, 173);
            this.lblSchool6.Name = "lblSchool6";
            this.lblSchool6.Size = new System.Drawing.Size(88, 20);
            this.lblSchool6.TabIndex = 104;
            this.lblSchool6.Visible = false;
            // 
            // lblSchool5
            // 
            this.lblSchool5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool5.Location = new System.Drawing.Point(207, 148);
            this.lblSchool5.Name = "lblSchool5";
            this.lblSchool5.Size = new System.Drawing.Size(88, 20);
            this.lblSchool5.TabIndex = 103;
            this.lblSchool5.Visible = false;
            // 
            // lblSchool4
            // 
            this.lblSchool4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool4.Location = new System.Drawing.Point(207, 122);
            this.lblSchool4.Name = "lblSchool4";
            this.lblSchool4.Size = new System.Drawing.Size(88, 20);
            this.lblSchool4.TabIndex = 102;
            this.lblSchool4.Visible = false;
            // 
            // lblSchool3
            // 
            this.lblSchool3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool3.Location = new System.Drawing.Point(207, 96);
            this.lblSchool3.Name = "lblSchool3";
            this.lblSchool3.Size = new System.Drawing.Size(88, 20);
            this.lblSchool3.TabIndex = 101;
            this.lblSchool3.Visible = false;
            // 
            // lblSchool2
            // 
            this.lblSchool2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool2.Location = new System.Drawing.Point(207, 69);
            this.lblSchool2.Name = "lblSchool2";
            this.lblSchool2.Size = new System.Drawing.Size(88, 20);
            this.lblSchool2.TabIndex = 100;
            this.lblSchool2.Visible = false;
            // 
            // lblSchool1
            // 
            this.lblSchool1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSchool1.Location = new System.Drawing.Point(207, 44);
            this.lblSchool1.Name = "lblSchool1";
            this.lblSchool1.Size = new System.Drawing.Size(88, 20);
            this.lblSchool1.TabIndex = 99;
            this.lblSchool1.Visible = false;
            // 
            // lblPerformance16
            // 
            this.lblPerformance16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance16.Location = new System.Drawing.Point(316, 434);
            this.lblPerformance16.Name = "lblPerformance16";
            this.lblPerformance16.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance16.TabIndex = 98;
            this.lblPerformance16.Visible = false;
            // 
            // lblPerformance15
            // 
            this.lblPerformance15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance15.Location = new System.Drawing.Point(316, 408);
            this.lblPerformance15.Name = "lblPerformance15";
            this.lblPerformance15.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance15.TabIndex = 97;
            this.lblPerformance15.Visible = false;
            // 
            // lblPerformance14
            // 
            this.lblPerformance14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance14.Location = new System.Drawing.Point(316, 381);
            this.lblPerformance14.Name = "lblPerformance14";
            this.lblPerformance14.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance14.TabIndex = 96;
            this.lblPerformance14.Visible = false;
            // 
            // lblPerformance13
            // 
            this.lblPerformance13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance13.Location = new System.Drawing.Point(316, 356);
            this.lblPerformance13.Name = "lblPerformance13";
            this.lblPerformance13.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance13.TabIndex = 95;
            this.lblPerformance13.Visible = false;
            // 
            // lblPerformance12
            // 
            this.lblPerformance12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance12.Location = new System.Drawing.Point(316, 330);
            this.lblPerformance12.Name = "lblPerformance12";
            this.lblPerformance12.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance12.TabIndex = 94;
            this.lblPerformance12.Visible = false;
            // 
            // lblPerformance11
            // 
            this.lblPerformance11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance11.Location = new System.Drawing.Point(316, 304);
            this.lblPerformance11.Name = "lblPerformance11";
            this.lblPerformance11.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance11.TabIndex = 93;
            this.lblPerformance11.Visible = false;
            // 
            // lblPerformance10
            // 
            this.lblPerformance10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance10.Location = new System.Drawing.Point(316, 277);
            this.lblPerformance10.Name = "lblPerformance10";
            this.lblPerformance10.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance10.TabIndex = 92;
            this.lblPerformance10.Visible = false;
            // 
            // lblPerformance9
            // 
            this.lblPerformance9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance9.Location = new System.Drawing.Point(316, 252);
            this.lblPerformance9.Name = "lblPerformance9";
            this.lblPerformance9.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance9.TabIndex = 91;
            this.lblPerformance9.Visible = false;
            // 
            // lblPerformance8
            // 
            this.lblPerformance8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance8.Location = new System.Drawing.Point(316, 226);
            this.lblPerformance8.Name = "lblPerformance8";
            this.lblPerformance8.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance8.TabIndex = 90;
            this.lblPerformance8.Visible = false;
            // 
            // lblPerformance7
            // 
            this.lblPerformance7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance7.Location = new System.Drawing.Point(316, 200);
            this.lblPerformance7.Name = "lblPerformance7";
            this.lblPerformance7.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance7.TabIndex = 89;
            this.lblPerformance7.Visible = false;
            // 
            // lblPerformance6
            // 
            this.lblPerformance6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance6.Location = new System.Drawing.Point(316, 173);
            this.lblPerformance6.Name = "lblPerformance6";
            this.lblPerformance6.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance6.TabIndex = 88;
            this.lblPerformance6.Visible = false;
            // 
            // lblPerformance5
            // 
            this.lblPerformance5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance5.Location = new System.Drawing.Point(316, 148);
            this.lblPerformance5.Name = "lblPerformance5";
            this.lblPerformance5.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance5.TabIndex = 87;
            this.lblPerformance5.Visible = false;
            // 
            // lblPerformance4
            // 
            this.lblPerformance4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance4.Location = new System.Drawing.Point(316, 122);
            this.lblPerformance4.Name = "lblPerformance4";
            this.lblPerformance4.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance4.TabIndex = 86;
            this.lblPerformance4.Visible = false;
            // 
            // lblPerformance3
            // 
            this.lblPerformance3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance3.Location = new System.Drawing.Point(316, 96);
            this.lblPerformance3.Name = "lblPerformance3";
            this.lblPerformance3.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance3.TabIndex = 85;
            this.lblPerformance3.Visible = false;
            // 
            // lblPerformance2
            // 
            this.lblPerformance2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance2.Location = new System.Drawing.Point(316, 69);
            this.lblPerformance2.Name = "lblPerformance2";
            this.lblPerformance2.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance2.TabIndex = 84;
            this.lblPerformance2.Visible = false;
            // 
            // lblPerformance1
            // 
            this.lblPerformance1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPerformance1.Location = new System.Drawing.Point(316, 44);
            this.lblPerformance1.Name = "lblPerformance1";
            this.lblPerformance1.Size = new System.Drawing.Size(86, 20);
            this.lblPerformance1.TabIndex = 83;
            this.lblPerformance1.Visible = false;
            // 
            // lblName16
            // 
            this.lblName16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName16.Location = new System.Drawing.Point(21, 433);
            this.lblName16.Name = "lblName16";
            this.lblName16.Size = new System.Drawing.Size(168, 20);
            this.lblName16.TabIndex = 82;
            this.lblName16.Visible = false;
            // 
            // lblName15
            // 
            this.lblName15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName15.Location = new System.Drawing.Point(21, 407);
            this.lblName15.Name = "lblName15";
            this.lblName15.Size = new System.Drawing.Size(168, 20);
            this.lblName15.TabIndex = 81;
            this.lblName15.Visible = false;
            // 
            // lblName14
            // 
            this.lblName14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName14.Location = new System.Drawing.Point(21, 380);
            this.lblName14.Name = "lblName14";
            this.lblName14.Size = new System.Drawing.Size(168, 20);
            this.lblName14.TabIndex = 80;
            this.lblName14.Visible = false;
            // 
            // lblName13
            // 
            this.lblName13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName13.Location = new System.Drawing.Point(21, 355);
            this.lblName13.Name = "lblName13";
            this.lblName13.Size = new System.Drawing.Size(168, 20);
            this.lblName13.TabIndex = 79;
            this.lblName13.Visible = false;
            // 
            // lblName12
            // 
            this.lblName12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName12.Location = new System.Drawing.Point(21, 329);
            this.lblName12.Name = "lblName12";
            this.lblName12.Size = new System.Drawing.Size(168, 20);
            this.lblName12.TabIndex = 78;
            this.lblName12.Visible = false;
            // 
            // lblName11
            // 
            this.lblName11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName11.Location = new System.Drawing.Point(21, 303);
            this.lblName11.Name = "lblName11";
            this.lblName11.Size = new System.Drawing.Size(168, 20);
            this.lblName11.TabIndex = 77;
            this.lblName11.Visible = false;
            // 
            // lblName10
            // 
            this.lblName10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName10.Location = new System.Drawing.Point(21, 276);
            this.lblName10.Name = "lblName10";
            this.lblName10.Size = new System.Drawing.Size(168, 20);
            this.lblName10.TabIndex = 76;
            this.lblName10.Visible = false;
            // 
            // lblName9
            // 
            this.lblName9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName9.Location = new System.Drawing.Point(21, 251);
            this.lblName9.Name = "lblName9";
            this.lblName9.Size = new System.Drawing.Size(168, 20);
            this.lblName9.TabIndex = 75;
            this.lblName9.Visible = false;
            // 
            // lblName8
            // 
            this.lblName8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName8.Location = new System.Drawing.Point(21, 225);
            this.lblName8.Name = "lblName8";
            this.lblName8.Size = new System.Drawing.Size(168, 20);
            this.lblName8.TabIndex = 74;
            this.lblName8.Visible = false;
            // 
            // lblName7
            // 
            this.lblName7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName7.Location = new System.Drawing.Point(21, 199);
            this.lblName7.Name = "lblName7";
            this.lblName7.Size = new System.Drawing.Size(168, 20);
            this.lblName7.TabIndex = 73;
            this.lblName7.Visible = false;
            // 
            // lblName6
            // 
            this.lblName6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName6.Location = new System.Drawing.Point(21, 172);
            this.lblName6.Name = "lblName6";
            this.lblName6.Size = new System.Drawing.Size(168, 20);
            this.lblName6.TabIndex = 72;
            this.lblName6.Visible = false;
            // 
            // lblName5
            // 
            this.lblName5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName5.Location = new System.Drawing.Point(21, 147);
            this.lblName5.Name = "lblName5";
            this.lblName5.Size = new System.Drawing.Size(168, 20);
            this.lblName5.TabIndex = 71;
            this.lblName5.Visible = false;
            // 
            // lblName4
            // 
            this.lblName4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName4.Location = new System.Drawing.Point(21, 121);
            this.lblName4.Name = "lblName4";
            this.lblName4.Size = new System.Drawing.Size(168, 20);
            this.lblName4.TabIndex = 70;
            this.lblName4.Visible = false;
            // 
            // lblName3
            // 
            this.lblName3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName3.Location = new System.Drawing.Point(21, 95);
            this.lblName3.Name = "lblName3";
            this.lblName3.Size = new System.Drawing.Size(168, 20);
            this.lblName3.TabIndex = 69;
            this.lblName3.Visible = false;
            // 
            // lblName2
            // 
            this.lblName2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName2.Location = new System.Drawing.Point(21, 68);
            this.lblName2.Name = "lblName2";
            this.lblName2.Size = new System.Drawing.Size(168, 20);
            this.lblName2.TabIndex = 68;
            this.lblName2.Visible = false;
            // 
            // lblName1
            // 
            this.lblName1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName1.Location = new System.Drawing.Point(21, 43);
            this.lblName1.Name = "lblName1";
            this.lblName1.Size = new System.Drawing.Size(168, 20);
            this.lblName1.TabIndex = 9;
            this.lblName1.Visible = false;
            // 
            // cboPlace16
            // 
            this.cboPlace16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace16.FormattingEnabled = true;
            this.cboPlace16.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace16.Location = new System.Drawing.Point(421, 433);
            this.cboPlace16.Name = "cboPlace16";
            this.cboPlace16.Size = new System.Drawing.Size(95, 21);
            this.cboPlace16.TabIndex = 16;
            this.cboPlace16.Visible = false;
            // 
            // cboPlace15
            // 
            this.cboPlace15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace15.FormattingEnabled = true;
            this.cboPlace15.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace15.Location = new System.Drawing.Point(421, 407);
            this.cboPlace15.Name = "cboPlace15";
            this.cboPlace15.Size = new System.Drawing.Size(95, 21);
            this.cboPlace15.TabIndex = 15;
            this.cboPlace15.Visible = false;
            // 
            // cboPlace14
            // 
            this.cboPlace14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace14.FormattingEnabled = true;
            this.cboPlace14.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace14.Location = new System.Drawing.Point(421, 381);
            this.cboPlace14.Name = "cboPlace14";
            this.cboPlace14.Size = new System.Drawing.Size(95, 21);
            this.cboPlace14.TabIndex = 14;
            this.cboPlace14.Visible = false;
            // 
            // cboPlace13
            // 
            this.cboPlace13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace13.FormattingEnabled = true;
            this.cboPlace13.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace13.Location = new System.Drawing.Point(421, 355);
            this.cboPlace13.Name = "cboPlace13";
            this.cboPlace13.Size = new System.Drawing.Size(95, 21);
            this.cboPlace13.TabIndex = 13;
            this.cboPlace13.Visible = false;
            // 
            // cboPlace12
            // 
            this.cboPlace12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace12.FormattingEnabled = true;
            this.cboPlace12.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace12.Location = new System.Drawing.Point(421, 329);
            this.cboPlace12.Name = "cboPlace12";
            this.cboPlace12.Size = new System.Drawing.Size(95, 21);
            this.cboPlace12.TabIndex = 12;
            this.cboPlace12.Visible = false;
            this.cboPlace12.SelectedIndexChanged += new System.EventHandler(this.cboPlace12_SelectedIndexChanged);
            // 
            // cboPlace11
            // 
            this.cboPlace11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace11.FormattingEnabled = true;
            this.cboPlace11.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace11.Location = new System.Drawing.Point(421, 303);
            this.cboPlace11.Name = "cboPlace11";
            this.cboPlace11.Size = new System.Drawing.Size(95, 21);
            this.cboPlace11.TabIndex = 11;
            this.cboPlace11.Visible = false;
            // 
            // cboPlace10
            // 
            this.cboPlace10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace10.FormattingEnabled = true;
            this.cboPlace10.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace10.Location = new System.Drawing.Point(421, 277);
            this.cboPlace10.Name = "cboPlace10";
            this.cboPlace10.Size = new System.Drawing.Size(95, 21);
            this.cboPlace10.TabIndex = 10;
            this.cboPlace10.Visible = false;
            // 
            // cboPlace9
            // 
            this.cboPlace9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace9.FormattingEnabled = true;
            this.cboPlace9.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace9.Location = new System.Drawing.Point(421, 251);
            this.cboPlace9.Name = "cboPlace9";
            this.cboPlace9.Size = new System.Drawing.Size(95, 21);
            this.cboPlace9.TabIndex = 9;
            this.cboPlace9.Visible = false;
            // 
            // cboPlace8
            // 
            this.cboPlace8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace8.FormattingEnabled = true;
            this.cboPlace8.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace8.Location = new System.Drawing.Point(421, 225);
            this.cboPlace8.Name = "cboPlace8";
            this.cboPlace8.Size = new System.Drawing.Size(95, 21);
            this.cboPlace8.TabIndex = 8;
            this.cboPlace8.Visible = false;
            // 
            // cboPlace7
            // 
            this.cboPlace7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace7.FormattingEnabled = true;
            this.cboPlace7.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace7.Location = new System.Drawing.Point(421, 199);
            this.cboPlace7.Name = "cboPlace7";
            this.cboPlace7.Size = new System.Drawing.Size(95, 21);
            this.cboPlace7.TabIndex = 7;
            this.cboPlace7.Visible = false;
            // 
            // cboPlace6
            // 
            this.cboPlace6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace6.FormattingEnabled = true;
            this.cboPlace6.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace6.Location = new System.Drawing.Point(421, 173);
            this.cboPlace6.Name = "cboPlace6";
            this.cboPlace6.Size = new System.Drawing.Size(95, 21);
            this.cboPlace6.TabIndex = 6;
            this.cboPlace6.Visible = false;
            // 
            // cboPlace5
            // 
            this.cboPlace5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace5.FormattingEnabled = true;
            this.cboPlace5.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace5.Location = new System.Drawing.Point(421, 147);
            this.cboPlace5.Name = "cboPlace5";
            this.cboPlace5.Size = new System.Drawing.Size(95, 21);
            this.cboPlace5.TabIndex = 5;
            this.cboPlace5.Visible = false;
            // 
            // cboPlace4
            // 
            this.cboPlace4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace4.FormattingEnabled = true;
            this.cboPlace4.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace4.Location = new System.Drawing.Point(421, 121);
            this.cboPlace4.Name = "cboPlace4";
            this.cboPlace4.Size = new System.Drawing.Size(95, 21);
            this.cboPlace4.TabIndex = 4;
            this.cboPlace4.Visible = false;
            // 
            // cboPlace3
            // 
            this.cboPlace3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace3.FormattingEnabled = true;
            this.cboPlace3.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace3.Location = new System.Drawing.Point(421, 95);
            this.cboPlace3.Name = "cboPlace3";
            this.cboPlace3.Size = new System.Drawing.Size(95, 21);
            this.cboPlace3.TabIndex = 3;
            this.cboPlace3.Visible = false;
            // 
            // cboPlace2
            // 
            this.cboPlace2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace2.FormattingEnabled = true;
            this.cboPlace2.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace2.Location = new System.Drawing.Point(421, 69);
            this.cboPlace2.Name = "cboPlace2";
            this.cboPlace2.Size = new System.Drawing.Size(95, 21);
            this.cboPlace2.TabIndex = 2;
            this.cboPlace2.Visible = false;
            // 
            // cboPlace1
            // 
            this.cboPlace1.BackColor = System.Drawing.SystemColors.Window;
            this.cboPlace1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlace1.FormattingEnabled = true;
            this.cboPlace1.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "- - -"});
            this.cboPlace1.Location = new System.Drawing.Point(421, 43);
            this.cboPlace1.Name = "cboPlace1";
            this.cboPlace1.Size = new System.Drawing.Size(95, 21);
            this.cboPlace1.TabIndex = 1;
            this.cboPlace1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(323, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Performance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "School";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // cmdEnter
            // 
            this.cmdEnter.Location = new System.Drawing.Point(12, 12);
            this.cmdEnter.Name = "cmdEnter";
            this.cmdEnter.Size = new System.Drawing.Size(200, 45);
            this.cmdEnter.TabIndex = 17;
            this.cmdEnter.Text = "Enter Data";
            this.cmdEnter.UseVisualStyleBackColor = true;
            this.cmdEnter.Click += new System.EventHandler(this.cmdEnter_Click);
            // 
            // FieldEventTieBreaker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 542);
            this.Controls.Add(this.cmdEnter);
            this.Controls.Add(this.grpPerformances);
            this.Name = "FieldEventTieBreaker";
            this.Text = "FieldEventTieBreaker";
            this.Load += new System.EventHandler(this.FieldEventTieBreaker_Load);
            this.grpPerformances.ResumeLayout(false);
            this.grpPerformances.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpPerformances;
        private System.Windows.Forms.Label lblSchool16;
        private System.Windows.Forms.Label lblSchool15;
        private System.Windows.Forms.Label lblSchool14;
        private System.Windows.Forms.Label lblSchool13;
        private System.Windows.Forms.Label lblSchool12;
        private System.Windows.Forms.Label lblSchool11;
        private System.Windows.Forms.Label lblSchool10;
        private System.Windows.Forms.Label lblSchool9;
        private System.Windows.Forms.Label lblSchool8;
        private System.Windows.Forms.Label lblSchool7;
        private System.Windows.Forms.Label lblSchool6;
        private System.Windows.Forms.Label lblSchool5;
        private System.Windows.Forms.Label lblSchool4;
        private System.Windows.Forms.Label lblSchool3;
        private System.Windows.Forms.Label lblSchool2;
        private System.Windows.Forms.Label lblSchool1;
        private System.Windows.Forms.Label lblPerformance16;
        private System.Windows.Forms.Label lblPerformance15;
        private System.Windows.Forms.Label lblPerformance14;
        private System.Windows.Forms.Label lblPerformance13;
        private System.Windows.Forms.Label lblPerformance12;
        private System.Windows.Forms.Label lblPerformance11;
        private System.Windows.Forms.Label lblPerformance10;
        private System.Windows.Forms.Label lblPerformance9;
        private System.Windows.Forms.Label lblPerformance8;
        private System.Windows.Forms.Label lblPerformance7;
        private System.Windows.Forms.Label lblPerformance6;
        private System.Windows.Forms.Label lblPerformance5;
        private System.Windows.Forms.Label lblPerformance4;
        private System.Windows.Forms.Label lblPerformance3;
        private System.Windows.Forms.Label lblPerformance2;
        private System.Windows.Forms.Label lblPerformance1;
        private System.Windows.Forms.Label lblName16;
        private System.Windows.Forms.Label lblName15;
        private System.Windows.Forms.Label lblName14;
        private System.Windows.Forms.Label lblName13;
        private System.Windows.Forms.Label lblName12;
        private System.Windows.Forms.Label lblName11;
        private System.Windows.Forms.Label lblName10;
        private System.Windows.Forms.Label lblName9;
        private System.Windows.Forms.Label lblName8;
        private System.Windows.Forms.Label lblName7;
        private System.Windows.Forms.Label lblName6;
        private System.Windows.Forms.Label lblName5;
        private System.Windows.Forms.Label lblName4;
        private System.Windows.Forms.Label lblName3;
        private System.Windows.Forms.Label lblName2;
        private System.Windows.Forms.Label lblName1;
        private System.Windows.Forms.ComboBox cboPlace16;
        private System.Windows.Forms.ComboBox cboPlace15;
        private System.Windows.Forms.ComboBox cboPlace14;
        private System.Windows.Forms.ComboBox cboPlace13;
        private System.Windows.Forms.ComboBox cboPlace12;
        private System.Windows.Forms.ComboBox cboPlace11;
        private System.Windows.Forms.ComboBox cboPlace10;
        private System.Windows.Forms.ComboBox cboPlace9;
        private System.Windows.Forms.ComboBox cboPlace8;
        private System.Windows.Forms.ComboBox cboPlace7;
        private System.Windows.Forms.ComboBox cboPlace6;
        private System.Windows.Forms.ComboBox cboPlace5;
        private System.Windows.Forms.ComboBox cboPlace4;
        private System.Windows.Forms.ComboBox cboPlace3;
        private System.Windows.Forms.ComboBox cboPlace2;
        private System.Windows.Forms.ComboBox cboPlace1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cmdEnter;
    }
}